# Cluster MKT™ application-foundation relay

## Objective

Initialize the cleaned Cluster MKT foundation as the public repository, establish the pnpm TypeScript workspace, implement the static branded web and Worker boundaries, validate them, and document the first implementation commit `398e8812a7d38db812b91067f7e82c507936f5c5`.

## Starting repository state

The local foundation was complete but had no `.git` metadata, package manager, application code, dependencies, tests, or CI. The public repository returned no refs. Pre-state evidence is preserved in `validation/`.

## Remote-repository state

`origin` is `https://github.com/dkyaya/ClusterMKT.git`. It was empty before initialization. No remote history was rewritten, no branch was deleted, and no force push was used.

## Git initialization or reconciliation performed

The existing directory was initialized directly, the branch was named `main`, `origin` was added exactly, and an empty fetch confirmed that no reconciliation commit was needed.

## Branch used

`main`

## Commit created

Implementation commit: `398e8812a7d38db812b91067f7e82c507936f5c5` — `Initialize Cluster MKT application foundation`.

## Push result

The implementation commit was pushed successfully to `origin/main`. Exact command evidence is in `validation/push-result.txt`.

## What changed

Created a private pnpm workspace; strict shared TypeScript configuration; React/Vite web shell; plain Cloudflare Worker; core, UI, and config packages; static Story Cluster fixtures; responsive edition-aware brand styling; behavior tests; ESLint; Prettier; GitHub Actions CI; runtime brand sync; validation tooling; and application/development documentation.

## Exact files created

- `.gitattributes`
- `.github/workflows/ci.yml`
- `.prettierignore`
- `.prettierrc.json`
- `apps/web/index.html`
- `apps/web/package.json`
- `apps/web/src/App.tsx`
- `apps/web/src/__tests__/App.test.tsx`
- `apps/web/src/__tests__/StoryClusterCard.test.tsx`
- `apps/web/src/__tests__/edition.test.ts`
- `apps/web/src/app/AppShell.tsx`
- `apps/web/src/app/routes.tsx`
- `apps/web/src/components/audio/BriefPlayerPreview.tsx`
- `apps/web/src/components/brand/ClusterMark.tsx`
- `apps/web/src/components/layout/EditionHeader.tsx`
- `apps/web/src/components/layout/PageContainer.tsx`
- `apps/web/src/components/navigation/DesktopSidebar.tsx`
- `apps/web/src/components/navigation/MobileBottomNav.tsx`
- `apps/web/src/components/story/PodcastCard.tsx`
- `apps/web/src/components/story/SourceCard.tsx`
- `apps/web/src/components/story/StoryClusterCard.tsx`
- `apps/web/src/components/story/StoryClusterTabs.tsx`
- `apps/web/src/data/demoClusters.ts`
- `apps/web/src/lib/edition.ts`
- `apps/web/src/lib/format.ts`
- `apps/web/src/main.tsx`
- `apps/web/src/pages/ClusterDetailPage.tsx`
- `apps/web/src/pages/NotFoundPage.tsx`
- `apps/web/src/pages/PlaceholderPage.tsx`
- `apps/web/src/pages/SettingsPage.tsx`
- `apps/web/src/pages/TodayPage.tsx`
- `apps/web/src/styles/edition-theme.css`
- `apps/web/src/styles/global.css`
- `apps/web/src/styles/layout.css`
- `apps/web/src/styles/reset.css`
- `apps/web/src/test/setup.ts`
- `apps/web/src/vite-env.d.ts`
- `apps/web/tsconfig.app.json`
- `apps/web/tsconfig.json`
- `apps/web/tsconfig.node.json`
- `apps/web/vite.config.ts`
- `apps/worker/package.json`
- `apps/worker/src/app.ts`
- `apps/worker/src/env.ts`
- `apps/worker/src/index.ts`
- `apps/worker/src/routes/health.ts`
- `apps/worker/src/routes/status.ts`
- `apps/worker/test/app.test.ts`
- `apps/worker/tsconfig.json`
- `apps/worker/wrangler.jsonc`
- `docs/architecture/APPLICATION_FOUNDATION.md`
- `docs/decisions/0004-application-foundation-stack.md`
- `docs/development/LOCAL_DEVELOPMENT.md`
- `docs/development/VALIDATION.md`
- `eslint.config.js`
- `package.json`
- `packages/config/package.json`
- `packages/config/src/__tests__/editions.test.ts`
- `packages/config/src/brand.ts`
- `packages/config/src/editions.ts`
- `packages/config/src/index.ts`
- `packages/config/src/navigation.ts`
- `packages/config/src/routes.ts`
- `packages/config/tsconfig.json`
- `packages/core/package.json`
- `packages/core/src/__tests__/relevance-label.test.ts`
- `packages/core/src/__tests__/story-cluster.test.ts`
- `packages/core/src/index.ts`
- `packages/core/src/lib/cluster-status.ts`
- `packages/core/src/lib/relevance-label.ts`
- `packages/core/src/schemas/edition.ts`
- `packages/core/src/schemas/podcast.ts`
- `packages/core/src/schemas/source.ts`
- `packages/core/src/schemas/story-cluster.ts`
- `packages/core/src/types/evidence.ts`
- `packages/core/tsconfig.json`
- `packages/ui/package.json`
- `packages/ui/src/__tests__/Tabs.test.tsx`
- `packages/ui/src/components/Badge.module.css`
- `packages/ui/src/components/Badge.tsx`
- `packages/ui/src/components/Button.module.css`
- `packages/ui/src/components/Button.tsx`
- `packages/ui/src/components/Surface.module.css`
- `packages/ui/src/components/Surface.tsx`
- `packages/ui/src/components/Tabs.module.css`
- `packages/ui/src/components/Tabs.tsx`
- `packages/ui/src/components/VisuallyHidden.tsx`
- `packages/ui/src/css-modules.d.ts`
- `packages/ui/src/index.ts`
- `packages/ui/src/styles/index.css`
- `packages/ui/src/test/setup.ts`
- `packages/ui/tsconfig.json`
- `pnpm-lock.yaml`
- `pnpm-workspace.yaml`
- `scripts/build_application_foundation_relay.py`
- `scripts/clean-generated.mjs`
- `scripts/sync-web-brand-assets.mjs`
- `scripts/validate-application-foundation.mjs`
- `tsconfig.base.json`
- `tsconfig.json`
- `vitest.workspace.ts`

## Exact files modified

- `.gitignore`
- `AGENTS.md`
- `README.md`
- `apps/web/README.md`
- `apps/worker/README.md`
- `docs/architecture/PLANNED_ARCHITECTURE.md`
- `docs/decisions/README.md`
- `packages/config/README.md`
- `packages/core/README.md`
- `packages/ui/README.md`
- `scripts/README.md`
- `tests/README.md`

## Exact files moved

None.

## Exact files deleted

None.

## Dependencies added and package versions

- `@cluster-mkt/config` — `link:../../packages/config`
- `@cluster-mkt/core` — `link:../core`
- `@cluster-mkt/ui` — `link:../../packages/ui`
- `@eslint/js` — `9.39.5`
- `@testing-library/jest-dom` — `6.9.1`
- `@testing-library/react` — `16.3.2`
- `@testing-library/user-event` — `14.6.1`
- `@types/node` — `24.13.3`
- `@types/react` — `19.2.17`
- `@types/react-dom` — `19.2.3`
- `@vitejs/plugin-react` — `5.2.0`
- `eslint` — `9.39.5`
- `eslint-plugin-jsx-a11y` — `6.10.2`
- `eslint-plugin-react-hooks` — `7.1.1`
- `eslint-plugin-react-refresh` — `0.4.26`
- `globals` — `16.5.0`
- `jsdom` — `27.4.0`
- `prettier` — `3.9.6`
- `react` — `19.2.8`
- `react-dom` — `19.2.8`
- `react-router-dom` — `7.18.2`
- `typescript` — `5.9.3`
- `typescript-eslint` — `8.65.0`
- `vite` — `7.3.6`
- `vitest` — `4.1.10`
- `wrangler` — `4.115.0`
- `zod` — `4.4.3`

All are open-source workspace runtime or development dependencies. No Tailwind, component library, state library, data-fetching library, Supabase client, AI SDK, animation library, or live-data client was added.

## Workspace structure

- `@cluster-mkt/web`: React/Vite demonstration application.
- `@cluster-mkt/worker`: plain Worker routes and dry-run build.
- `@cluster-mkt/core`: Zod evidence and Story Cluster contracts.
- `@cluster-mkt/ui`: accessible token-driven primitives.
- `@cluster-mkt/config`: non-secret routes, identity, navigation, and edition logic.

## Web application structure

The responsive shell includes desktop and mobile navigation, static search presentation, Today, Story Cluster detail, placeholder routes, settings previews, a nonfunctional audio preview, and explicit demonstration-data labeling. Detail clusters present Overview, Read, and Listen with source roles, relevance, reasons for inclusion, overview-use flags, transcript status, and related-listening disclosures.

## Worker structure

`GET /health` returns structured health data. `GET /api/status` explicitly reports live data, authentication, and external AI as false. Unknown routes return 404. The Wrangler build is a telemetry-disabled dry run with no bindings and no deployment.

## Shared-package structure

Core preserves framework-independent evidence semantics. Config centralizes deterministic America/New_York edition boundaries. UI provides Button, Badge, Surface, Tabs, and VisuallyHidden primitives with keyboard behavior and reduced-motion-aware brand styles.

## Brand integration

The canonical package stays under `brand/`. The web build imports the locked light/dark dimensional masters directly. Exactly nine runtime icons are generated from `brand/icons/` into ignored `apps/web/public/brand/`, and the validator compares hashes. All locked master hashes remained unchanged.

## Runtime-generated brand-asset policy

`apps/web/public/brand/` is ignored, removed by `pnpm clean`, and regenerated by development, build, CI, or `pnpm assets:sync`. It is never an alternate source of truth.

## Edition implementation

Morning begins at 06:00 ET, Midday at 12:00 ET, and Closing at 18:00 ET through 05:59 ET. Deterministic tests cover every transition. `data-edition` affects restrained accent tokens while `prefers-color-scheme` independently controls appearance; Closing never forces dark mode.

## Testing performed

Vitest executed 25 behavior tests across 8 files: schema acceptance/rejection, evidence flags, podcast transcript safety, deterministic relevance labels, edition boundaries, accessible tabs, UI labels, app/navigation/demo rendering, cluster cards, and Worker responses.

## CI configuration

GitHub Actions runs on pull requests and pushes to `main` using Node 24 LTS, pnpm 10.26.2, Python 3.12, a frozen lockfile, asset sync, formatting, lint, type-checking, tests, builds, brand validation, and foundation validation. It has read-only repository permission and no deploy step.

## Validation commands

```sh
pnpm install --frozen-lockfile
pnpm assets:sync
pnpm format:check
pnpm lint
pnpm typecheck
pnpm test:run
pnpm build:web
pnpm build:worker
pnpm brand:validate
pnpm foundation:validate
pnpm validate
```

## Validation results

- Formatting: PASS.
- ESLint: PASS with zero warnings.
- Strict TypeScript: PASS across five workspace packages.
- Tests: PASS, 25/25 across 8 files.
- Web build: PASS, 168 modules; both locked dimensional marks bundled as SVG.
- Worker build: PASS, 2.12 KiB dry-run upload, no bindings, no deployment.
- Brand: PASS, 11/11 groups.
- Application foundation: PASS, 24/24 checks.
- Locked masters: PASS, 5/5 exact hashes.

## What worked

One workspace lockfile supports all boundaries, source schemas reject unsafe podcast evidence, edition selection remains deterministic, the visual shell stays honestly static, brand sources remain canonical, and local/CI gates share the same commands.

## Failures encountered and repairs

- The first pnpm install resolved a deprecated matcher patch; it was pinned to 6.9.1 and the lockfile refreshed.
- Initial type-checking needed CSS-module declarations and reference-free leaf checks; both were corrected without reducing strictness.
- Vitest 4 removed the old workspace flag and projects were moved into the supported configuration. Explicit cleanup fixed test isolation.
- The sandbox blocked Wrangler's user-level log path; the authorized dry-run succeeded. Metrics are now explicitly disabled.
- Optional screenshot capture was attempted with the available browser control surface, but no controllable browser instance was available. No browser dependency was added; `previews/README.md` records this.

## Remaining uncertainties

Visual review should still be performed in the product owner's browsers. The final editorial serif and previously documented brand-owner/legal approvals remain open. GitHub Actions will provide the first remote Linux/Node 24 execution after push.

## Remaining blockers

No implementation or push blocker remains for this phase.

## Items requiring user approval

Product-owner visual approval of the shell and inherited brand typography/trademark decisions remain appropriate before production design expansion.

## Recommended next phase

Design a source registry and publisher/feed capability matrix, canonical source metadata, an entity-resolution dictionary, relevance-scoring fixtures, Story Cluster fixtures, and adversarial ticker-collision cases. Keep all ingestion offline and fixture-driven.

## Reproduction commands

```sh
pnpm install --frozen-lockfile
pnpm validate
python scripts/build_application_foundation_relay.py
```

## SHA-256 hashes

- `cluster-mkt-mark-dimensional-light.svg` — `66496cfe8dc2d6abb51c5b5a58824ca751db2de0d9a65be621f083bc075b11a1`
- `cluster-mkt-mark-dimensional-dark.svg` — `b8c4d7a36ae24daf5bb6e785dc41d9e6c4b01649e5eb5c55959763b5faa3405b`
- `cluster-mkt-mark-flat.svg` — `2dfae7aaf3524a80fe86a56f2fb3a1fa01b866c55abf11e3faf86aa6ef8ca992`
- `cluster-mkt-mark-monochrome-black.svg` — `037232276468c91ce7bb70daac33bc615f83ee3942855d4bd7b337e074fe5850`
- `cluster-mkt-mark-monochrome-white.svg` — `b676c0856aaa5b0c2bca0a687df8519b5c2c069044fa2e40ce0605c44b703542`

Every relay member is inventoried in `manifest.json`. The relay filename is `cluster-mkt-application-foundation-relay-2026-07-28-398e8812.zip`.

## Suggested Codex profile for the next phase

Heavy — GPT-5.6 Sol High.

## PLAIN-ENGLISH TRANSLATION

Cluster MKT now has a real development foundation. The website displays a polished, responsive, brand-aligned preview of Today, Story Cluster details, sources, podcasts, settings, and navigation. Every story, count, timestamp, source, and control is explicitly demonstration material; no live market service is attached.

The Worker only answers health and status questions and truthfully reports that live data, authentication, and AI are disconnected. Code is separated into browser, Worker, domain, UI, and configuration packages. Tests protect evidence rules, edition timing, accessibility behavior, page rendering, and Worker routing. The public GitHub `main` branch received the implementation commit.

The brand is used directly from its locked masters and canonical tokens; browser icons are reproducibly generated rather than copied by hand. Nothing has been deployed, and ingestion, accounts, persistence, publisher connections, AI, podcasts, and TTS remain unconnected. Next, build offline source metadata and adversarial relevance/clustering fixtures before any live ingestion.
