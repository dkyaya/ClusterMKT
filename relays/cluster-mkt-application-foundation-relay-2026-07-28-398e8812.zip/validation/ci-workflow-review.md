# CI workflow review

PASS. The workflow triggers on pull requests and pushes to `main`, uses maintained official checkout/pnpm/Node/Python actions, installs pinned Python brand-validator dependencies and Chromium, installs the frozen pnpm lockfile, runs all requested gates, has read-only contents permission, declares no secrets, and contains no deployment step.
