# Cluster MKT — Blind Multi-Agent Calibration Pilot Relay

Date: 2026-08-04
Implementation commit: `0185556` (`0185556c206f69e1fc6e2699a230a86dcc29f28f`)
Branch: `main`

## Objective

Replace the unavailable multi-human review requirement with a transparent, reproducible, blinded
multi-agent calibration system: build the full coordinator/worker infrastructure, run a bounded
52-item pilot through isolated agent reviewer panels, adjudicate disputed/high-risk cases, route
genuinely difficult cases to an owner-review queue, and repair/complete browser acceptance for the
resulting reviewer interfaces — without ever claiming agent review is equivalent to independent
human review.

## Starting state

Clean `main` at `11b1c59` ("Add gold calibration corpus relay"), `pnpm validate` passing (24/24
foundation checks). The existing gold-calibration-corpus and human reviewer workflow
(345-item corpus, `/dev/review`, `/dev/adjudication`) were already implemented and untouched by
this phase.

## Worker orchestration capability

Available. Two mechanisms were used: the `Agent` tool for one-off isolated calls, and the
`Workflow` tool (`agent()`/`pipeline()`/`parallel()`) to orchestrate the pilot's ~450 planned
isolated subagent calls (reviewer panels, adjudicators, repeat-stability panels) deterministically.
See `worker-capability-assessment.md`.

## Isolation design

A coordinator (this implementation) builds blinded evidence packets per (item, role) and assigns
them to isolated Claude Agent SDK subagent calls with pseudonymous ids (`reviewer-alpha` through
`reviewer-golf`). Each call starts with zero shared memory — no visibility into pipeline
predictions, existing gold labels, other reviewers' decisions, adjudication outcomes, consensus
statistics, coordinator preferences, or prior answers for the same item. Packets never contain the
internal `gold-item-XXXX` id or a repository file path; every worker prompt explicitly instructs
the agent not to read repository files. **Documented limitation:** neither `Agent` nor `Workflow`
exposes a parameter to revoke a spawned subagent's tool access, so isolation here is content
isolation plus instruction, not a hard sandbox — see `worker-capability-assessment.md` for the full
assessment. This is recorded rather than glossed over.

## Reviewer roles

Seven roles, each with purpose, allowed/forbidden evidence, checklist, confidence scale,
escalation rules, and versioned prompt/role ids: `literal_evidence_reviewer`,
`source_provenance_reviewer`, `adversarial_reviewer`, `domain_context_reviewer`,
`conservative_gatekeeper`, `quantitative_integrity_reviewer`, `event_boundary_reviewer`.

## Packet blinding rules

A packet includes only: opaque packet id/hash, task, role, risk class, difficulty class, reviewer
instructions, allowed labels, a handbook excerpt, the evidence package, and permitted provenance
fields. It excludes: predictions, gold labels, other reviewers' decisions, prior adjudication,
consensus information, the unblinded item id, and any file path that would reveal an expected
outcome. `scripts/build-agent-review-packets.mjs` validates every packet against 18 forbidden
markers before use.

## Pilot sampling

52 items, deterministically stratified-selected from the existing 345-item gold corpus (seed
`cluster-mkt-agent-pilot-v1-seed`), with the required exact task distribution (10/10/8/8/6/5/5) and
cross-cutting adversarial minimums. One cross-cutting minimum (≥6 quantitative-claim items) is
**mathematically unreachable** within this task distribution: every `claimType=quantitative_fact`
item in `gold-corpus-v1` belongs to `story_cluster_membership`, a task excluded from this pilot's
required 7-task split. Two further minimums (metadata-limited, evolving/corrected) fell 1 and 2
short respectively because their supplying tasks (`event_boundaries`, `claims`) each also carry
another single-task-dependent adversarial requirement that competes for the same fixed quota. All
three gaps are recorded with root cause in `tests/fixtures/agent-review-pilot/pilot-selection.json`
under `knownLimitations`, not silently dropped.

## Panel sizes

3 reviewers (low risk), 5 (standard), 7 (high risk), per `packages/config/src/calibration/agent-panel-policy.ts`.
Of the 52 pilot items: 38 high risk, 4 standard, 10 low — the pilot's own adversarial stratification
concentrates risk, so this distribution is expected, not a bug. Target reviewer decisions: 316
(main pilot) + 50 (10-item repeat-stability subset) = 366.

## Total reviewer decisions

**Collected for real: 29 of 316** (plus 0 of 50 repeat-stability decisions), across 5 items:
`gold-item-0002` (7/7), `gold-item-0004` (7/7), `gold-item-0005` (7/7), `gold-item-0009` (7/7),
`gold-item-0017` (1/7). The remaining 47 pilot items and all 10 repeat-stability items collected
zero decisions. **Root cause:** a recurring Claude session usage limit interrupted every resume
attempt after roughly 15–35 successful agent calls, with the reported reset time shifting later on
each retry (10:50pm → 3:10pm → 8pm America/New_York across three attempts) — consistent with a
rolling/short usage window rather than a fixed daily reset. Three resume attempts were made; each
netted meaningfully fewer than the ~450 calls needed to finish. See "Limitations" below.

## Agreement results

Among the 5 items with any real decisions: 2 unanimous, 2 majority (~0.94 average majority share),
1 insufficient. No high-confidence critical dissent occurred. This is far too small a completed
sample to characterize the pilot's overall agreement and is reported as such — see
`validation/agent-panel-agreement-report.json`.

## Dissent results

Zero dissent recorded among the completed panels (the 2 unanimous and 2 majority items did not
produce a high-confidence critical minority position in this partial run).

## Adjudication results

2 adjudications completed for real (`gold-item-0002` → `agent_adjudicated_review_required`,
`gold-item-0004` → `agent_adjudicated`), both referencing only anonymized `panel-member-N` ids. 3
further adjudication attempts were themselves interrupted by the limit and are explicitly flagged
`ADJUDICATION_ATTEMPT_FAILED` rather than left ambiguous. See `validation/agent-adjudication-report.json`.

## Repeat-stability results

**0 of 10 repeat-run comparisons are genuinely comparable** — for every pair, at least one of the
two runs (first or repeat) collected zero decisions. `scripts/evaluate-agent-repeat-stability.mjs`
excludes these from the `inter_agent_repeat_stability` rate and reports them separately as
execution gaps rather than counting an interrupted run as a real disagreement between panels. No
stability rate is claimed from this run. See `validation/agent-repeat-stability-report.json`.

## Owner-escalation results

13 of 52 items are in the owner-review queue (8 `required_before_display`, 5 `recommended`); every
entry has a recorded reason. **Known limitation:** the 5 `sector_coverage` items flagged
`SECTOR_WIDE_CLASSIFICATION_DISPUTED` did not actually collect any decisions in this run — the
escalation logic treats any non-unanimous/non-strong-consensus outcome for that task as a dispute
signal without distinguishing "the panel disagreed" from "the panel never ran." The resulting
escalation is still safe (nothing was auto-promoted), but the reason label is imprecise for
zero-decision items and should be refined before scaling. See `validation/owner-escalation-report.json`.

## Comparison with fixture expectations

`gold-corpus-v1` currently has zero finalized human-gold labels (by design — see
`docs/architecture/GOLD_CALIBRATION_CORPUS.md`), so there is no existing fixture expectation to
compare the 5 completed agent-panel outcomes against in this phase. No comparison table is
fabricated in its absence.

## Browser-tool repair

No repair was required — `mcp__claude-in-chrome__tabs_context_mcp` connected successfully on the
first call. A real environment quirk was found and worked around: the first browser tab's window
was OS-snapped to roughly half the display, which silently capped `resize_window` requests despite
reporting success (verified via `window.innerWidth` reads, not the tool's return message alone). A
fresh, unsnapped tab tracked requested sizes exactly. See `browser-tool-repair.md`.

## Browser validation

Passed. `/dev/agent-panels` and `/dev/agent-panels/:itemId` were inspected at desktop (1500×763
actual, close to the 1440×1000 target) and a mobile-scale width (~606px CSS, closest achievable in
this display to the 390×844 target — both deviations are recorded honestly rather than claimed
exact). Zero console errors, zero unexpected network requests, no consumer-navigation exposure, no
reviewer-identity leakage in the adjudication display, correct dissent/adjudication/owner-escalation
rendering, and no horizontal overflow at the narrower width. Regression-checked: `/dev/review`,
`/dev/adjudication`, and `/` (Today) all still load cleanly. See `browser-validation-results.md`,
`browser-console.txt`, `browser-network.txt`.

## Files created (55)

Schemas (10): `agent-reviewer-role.ts`, `agent-review-packet.ts`, `agent-review-decision.ts`,
`agent-panel-result.ts`, `agent-dissent.ts`, `agent-adjudication.ts`, `owner-review-queue-item.ts`,
`provisional-benchmark-label.ts` (packages/core/src/schemas), plus `types/agent-review.ts`.

Lib (16, packages/core/src/lib): `agent-review-packet.ts`, `agent-review-blinding.ts`,
`agent-review-redaction.ts`, `agent-review-validation.ts`, `agent-worker-isolation.ts`,
`agent-worker-assignment.ts`, `agent-worker-output.ts`, `agent-panel-policy.ts`,
`agent-panel-aggregation.ts`, `inter-agent-agreement.ts`, `agent-dissent-analysis.ts`,
`evidence-overlap.ts`, `agent-adjudication.ts`, `agent-adjudication-routing.ts`,
`agent-adjudication-validation.ts`, `owner-escalation.ts`, `provisional-benchmark-promotion.ts`.

Config (3, packages/config/src/calibration): `agent-reviewer-roles.ts`, `agent-panel-policy.ts`,
`agent-pilot-v1.ts`.

Scripts (10): `build-agent-review-packets.mjs`, `select-agent-review-pilot.mjs`,
`validate-agent-review.mjs`, `evaluate-agent-review-pilot.mjs`, `evaluate-agent-panel-agreement.mjs`,
`evaluate-agent-adjudication.mjs`, `evaluate-agent-repeat-stability.mjs`,
`evaluate-owner-escalation.mjs`, `lib/agent-review-pilot-shared.mjs`, `lib/agent-review-reporting.mjs`.

Web UI (10): `AgentPanelDashboardPage.tsx`, `AgentPanelItemPage.tsx`,
`AgentPanelSummary.tsx`, `AgentReviewerDecisionCard.tsx`, `AgentDissentCard.tsx`,
`AgentAdjudicationCard.tsx`, `OwnerEscalationCard.tsx`, `AgentAgreementMetrics.tsx`,
`ReviewerIsolationStatus.tsx`, `demoAgentPanelReview.ts`.

Docs (5): `BLIND_MULTI_AGENT_REVIEW.md`, `AGENT_REVIEW_DISCLOSURE.md`, decisions `0019`, `0020`, `0021`.

Fixtures (1): `tests/fixtures/agent-review-pilot/pilot-selection.json`.

## Files modified (17)

`README.md`, `AGENTS.md`, `CLAUDE.md` (no — not modified), `package.json` (agent-review:* scripts),
`packages/core/src/index.ts`, `packages/config/src/index.ts`, `apps/web/src/app/routes.tsx`,
`apps/web/README.md`, `packages/core/README.md`, `packages/config/README.md`, `tests/README.md`,
`docs/decisions/README.md`, `docs/architecture/GOLD_CALIBRATION_CORPUS.md`,
`docs/architecture/REVIEWER_WORKFLOW.md`, `docs/development/LOCAL_DEVELOPMENT.md`,
`docs/development/VALIDATION.md`, `docs/product/ANNOTATION_POLICY.md`,
`docs/product/PRODUCT_FOUNDATION.md`. (Exact list: `git diff --name-status 11b1c59 0185556`.)

## Files moved / deleted

None.

## Validation

`pnpm validate` passes end to end (exit 0), including the new `agent-review:validate` gate, which
reports `passed_with_incomplete_pilot`: every critical safety gate passes (zero packet leakage,
zero malformed submissions, every item has a terminal state, every high-risk item is adjudicated or
held in a non-promotable state, every owner escalation has a reason, no disputed panel is marked
unanimous, no high-risk item was bare-majority-promoted, every adjudication references anonymized
members only); only the informational "did every panel finish" flag is false, and it says so.
`pnpm lint`, `pnpm typecheck`, `pnpm test:run` (357/357), `pnpm build`, and `pnpm brand:validate`
all pass. See `format-check.txt`, `lint.txt`, `typecheck.txt`, `tests.txt`, `build.txt`,
`validation-full-run-3.txt` (final full `pnpm validate` log).

## Failures and repairs

1. **`args` arrives as a raw JSON string, not a parsed object, in this Workflow runtime.** Two
   initial pilot launches failed instantly (0 agents run) with `undefined is not an object
   (evaluating 'args.items.length')`. A minimal diagnostic workflow confirmed `typeof args ===
   "string"` regardless of how args was passed. Fixed by parsing `args` defensively at the top of
   the script (`typeof args === "string" ? JSON.parse(args) : args`) before first use.
2. **Recurring session usage limit** interrupted every real pilot run after a burst of agent calls.
   Documented above and in "Limitations"; not worked around by fabricating results.
3. **Two validate-script checks were too blunt** and flagged real, correctly-guarded outcomes as
   failures (a high-risk item resolved to `owner_review_required` rather than the literal string
   `unresolved`; a high-risk item reached `agent_panel_majority` at the *panel* level but was
   already correctly held at `unresolved` at the *provisional-state* level). Fixed by checking
   `provisionalState` — the actual promotion gate — instead of the raw panel outcome.
4. **Repeat-stability rate would have conflated execution failures with real instability.** Fixed
   by requiring both runs to have collected ≥1 valid decision before counting a comparison as
   informative; execution gaps are now reported separately.
5. **Window-snap browser-resize quirk** — see "Browser-tool repair" above.

## Implementation commit

`0185556` "Build blind multi-agent calibration pilot" on `main`, pushed to `origin/main`
successfully (`11b1c59..0185556 main -> main`). See `push-result.txt`.

## Push result

Succeeded. `git ls-remote origin main` confirms `origin/main` is at `0185556c206f69e1fc6e2699a230a86dcc29f28f`.

## Limitations

- The 52-item pilot is **9% complete by decision count** (29/316 main + 0/50 repeat). This is the
  single largest limitation of this phase and is not disguised anywhere in the code, UI, or docs —
  `pnpm agent-review:validate` reports `passed_with_incomplete_pilot`, the dashboard states the
  exact completion numbers, and this document leads with them.
- 3 cross-cutting pilot-sampling minimums could not be fully met given the real corpus's strata
  distribution (see "Pilot sampling" above); root cause is recorded in the fixture itself.
- The `SECTOR_WIDE_CLASSIFICATION_DISPUTED` owner-escalation reason is imprecise for zero-decision
  items (see "Owner-escalation results").
- Worker isolation is content isolation plus instruction, not a hard tool sandbox (see "Isolation
  design").

## Remaining uncertainty

Whether the recurring usage limit is a fixed daily quota, a rolling window, or something else
entirely was not determined with confidence — the observed reset times shifted later on each of
three attempts, which is consistent with a rolling window but not conclusively established.

## Recommended next phase

**Path A: multi-agent workflow repair**, specifically resuming pilot execution once the usage
window is confirmed clear (a large, uninterrupted block of time, or a session with more available
quota), then re-running `pnpm agent-review:report` and `pnpm agent-review:validate` against the
completed data. Do not attempt Path B (scale) or Path C (source onboarding) until the pilot itself
is complete and the two documented logic caveats (sector-escalation precision, sampling gaps) are
resolved or explicitly re-affirmed as acceptable.

## Reproduction commands

```sh
pnpm install
node scripts/select-agent-review-pilot.mjs
node scripts/build-agent-review-packets.mjs
# Resume/complete the pilot via the Workflow tool using the saved script and lean args manifest,
# then save its return value to .tmp/agent-review-pilot/results/pilot-results.json
pnpm agent-review:validate
pnpm agent-review:report
pnpm validate
```

## SHA-256 hashes

See `manifest.json` for a full per-file SHA-256 manifest of every file in this relay package.
Locked brand masters are unchanged (`locked-master-hashes-before.json` ==
`locked-master-hashes-after.json`, diffed with zero output).

## Suggested future model profile

Claude Sonnet 5.0 High (unchanged) — the bottleneck in this phase was session usage quota, not
model capability or reasoning depth.

---

## PLAIN-ENGLISH TRANSLATION

**How one coordinator created separate reviewer workers.** This session acted as the coordinator:
it read 52 evidence items from an existing offline test corpus, stripped out anything that could
reveal the "right answer," and handed each stripped-down packet to a fresh, separate AI agent with
no memory of anything else happening in the project. Each of those agents is one "reviewer."

**Why reviewers couldn't see one another's answers.** Every reviewer agent was started from a blank
slate — it only ever saw the one evidence packet it was given, plus instructions for its specific
role (e.g., "look for anything that seems too good to be true" or "check the numbers add up"). It
had no way to know what any other reviewer said, because it never existed in the same conversation
as any other reviewer.

**Why reviewers couldn't see the pipeline's prediction.** The evidence packets were built to
specifically exclude any existing guess, prediction, or answer key, and the packets themselves
never contain the internal ID that would let a curious agent go look one up.

**How many agents reviewed each kind of item.** Low-risk items got 3 reviewers, medium-risk items
got 5, and high-risk items (ambiguous company names, numbers, disputed events) got 7 — the riskier
the item, the more independent opinions it required.

**How disagreement was handled.** If most reviewers agreed, that's noted as a majority or unanimous
result. If a reviewer strongly disagreed in a way that looked serious (not just a shrug), that
disagreement is flagged and never hidden.

**How adjudication worked.** For any item where the panel didn't cleanly agree, a completely
separate "judge" agent — who also never saw who said what, just anonymized labels like
"panel-member-3" — looked at the same evidence and the anonymized opinions and made a final call.

**Which cases still require owner attention.** 13 of the 52 items were flagged for a human owner to
look at, each with a specific written reason (e.g., "the source-checking reviewer raised a
provenance concern" or "an ambiguous ticker/company name creates a false-match risk").

**What agent agreement does and does not prove.** When several AI agents agree, that's a mildly
useful signal that the answer is probably reasonable — but it is explicitly NOT the same thing as
several independent human experts agreeing, and the system never claims otherwise anywhere in the
code, docs, or on-screen text.

**What was stress-tested.** The system correctly refused to "make up" an answer when something went
wrong: when the AI reviewer calls failed partway through (see below), the system did not pretend
those items had results — it honestly marked them as "no decision collected" and routed them
conservatively, rather than showing a fake outcome.

**The honest bad news.** This session ran into a usage limit — essentially, the account this ran
under had a cap on how many AI agent calls could happen in a given stretch of time, and that cap
kept getting hit after only a small fraction of the full 52-item review was done (about 29 of the
316 planned decisions, roughly 9%). Multiple retries were attempted; the limit kept coming back.
Rather than fake the missing 91%, this run reports exactly what did and didn't complete, both in
the code's own validation gate and in this document.

**Whether browser acceptance passed.** Yes — the new reviewer-panel screens were opened in a real
browser at both desktop and phone-ish sizes, checked for errors, and screenshotted.

**Whether the repository was updated.** Yes — everything described above (except the unfinished
pilot data itself) is fully built, tested, and pushed to the main branch.

**What should happen next.** Re-run the pilot to completion once a bigger block of usage quota is
available, then re-check the two minor logic issues noted above (the sector-escalation label being
imprecise for empty panels, and the three sampling gaps) before treating any of this as more than a
provisional pilot.
