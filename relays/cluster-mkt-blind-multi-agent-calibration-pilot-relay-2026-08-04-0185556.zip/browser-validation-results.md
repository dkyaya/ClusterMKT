# Browser validation results

Dev server: `pnpm dev:web` at `http://localhost:5173/` (Vite 7.3.6). Verified with
`mcp__claude-in-chrome__*` tools (real screenshots, console reads, network reads — not curl).

## Widths actually achieved

- Desktop: 1500×763 CSS px (requested 1440×1000; verified via `window.innerWidth`/`innerHeight`
  read through `javascript_tool`, not assumed from the tool's return message). Close enough to the
  1440×1000 target to be a valid desktop-layout check; see `browser-tool-repair.md` for why the
  exact figure differs.
- Mobile: ~606×? CSS px (requested 390×844; the display/window manager would not shrink an
  already-larger window below ~600px CSS width). This is narrower than the desktop breakpoint and
  wide enough to exercise the mobile bottom-nav layout, but is not the exact 390px target — recorded
  honestly rather than claimed as exact.

## Pages inspected

| Route | Loads | Console errors | Notes |
| --- | --- | --- | --- |
| `/dev/agent-panels` | yes | none | Desktop: sidebar nav, 4-col metrics grid, 3-col outcome cards render. Mobile (~606px): bottom nav, single-column cards, no horizontal overflow (`scrollWidth === clientWidth`, verified via JS). |
| `/dev/agent-panels/gold-item-0261` | yes | none | Disputed/high-risk example: dissent card shows `panel-member-6 · quantitative_integrity_reviewer` with a `critical` badge (reviewer pseudonym never shown); adjudication card shows anonymized accept/reject ids only; owner-escalation card shows `required_before_calibration` with reasons; no-human-validation disclaimer visible. Verified on both desktop and mobile widths. |
| `/dev/agent-panels/gold-item-0002` | yes | none | Unanimous/low-dissent example, reachable from the dashboard list. |
| `/dev/review` (existing reviewer workbench) | yes | none | Unmodified by this phase; regression-checked, renders identically to before. |
| `/dev/adjudication` (existing) | yes | none | Regression-checked, loads without error. |
| `/` (Today, consumer-facing) | yes | none | Regression-checked. Sidebar nav shows Today/Watchlist/Sectors/Saved/Listen/Calendar/Settings/Profile only — no `/dev/*` links, confirming the new agent-panel pages are absent from consumer navigation. |

## Requirement checklist

- Reviewer workflow loads: yes (`/dev/review`, unmodified, regression-checked).
- Agent panel dashboard loads: yes.
- Agent panel item loads: yes.
- Reviewer roles display correctly: yes (role name shown next to each anonymized decision).
- Agent disclosure visible: yes ("Agents, not humans" badge, isolation card, boundary notes).
- Provisional status visible: yes (panel outcome + provisional state shown on every card).
- Predictions remain hidden where required: yes (packets/decisions never reference
  `hiddenPrediction`, gold labels, or pipeline output — enforced by the same schema/data used by the
  leakage validator, `scripts/validate-agent-review.mjs`, which passes 0 leakage on the real packet
  manifest).
- Dissent visible: yes.
- Adjudication visible: yes.
- Owner escalation visible: yes.
- Packet hash visible: yes (dashboard header and item header).
- No reviewer identity leakage in adjudication display: yes — adjudication card and dissent card
  show only anonymized `panel-member-N` ids, never `reviewer-alpha` etc.
- No answer leakage: yes — no expected/gold label field exists anywhere in the demo data or the
  underlying schema.
- No consumer-navigation exposure: yes (confirmed above).
- Responsive layout / no mobile overflow: yes, verified via `document.documentElement.scrollWidth`
  vs `clientWidth` at ~606px.
- Light/dark and edition accents: not re-tested separately in this pass — the new pages reuse
  existing `reviewer-card`/`Badge`/`Surface` components and CSS custom properties (`--color-*`)
  already validated for light/dark/edition support in prior phases; no new color literals were
  introduced.
- Reduced motion: unaffected — no new animation was added.

## Console and network

See `browser-console.txt` and `browser-network.txt`. No errors on any inspected route. The app made
zero network requests beyond the Vite dev-server assets (no API calls), consistent with the
offline-fixture design.
