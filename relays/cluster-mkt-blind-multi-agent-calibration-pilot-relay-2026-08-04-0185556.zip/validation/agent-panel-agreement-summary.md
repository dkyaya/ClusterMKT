# Agent panel agreement summary

Across the 52 items, panel outcomes were: 2 `agent_panel_unanimous`, 2 `agent_panel_majority`, 1 `agent_panel_insufficient`, 47 `agent_panel_invalid` (zero decisions collected — a session-limit artifact, not a disagreement). Among the 5 items that received any real decisions, average majority share was ~0.94 and no critical high-confidence dissent occurred. This is a reliability signal only, computed from too small a completed sample to characterize the full pilot, and is never described as human inter-rater agreement.
