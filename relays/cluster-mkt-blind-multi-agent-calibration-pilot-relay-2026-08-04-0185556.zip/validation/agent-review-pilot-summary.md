# Agent review pilot summary

The 52-item pilot was selected deterministically from the existing 345-item gold corpus (see `tests/fixtures/agent-review-pilot/pilot-selection.json`). Execution began for real through isolated Claude Agent SDK subagent calls orchestrated by a Workflow script, but a recurring per-session usage limit repeatedly interrupted the run before all 316 target reviewer decisions could be collected.

**What actually completed:** 29 of 316 reviewer decisions (4 items — `gold-item-0002`, `gold-item-0004`, `gold-item-0005`, `gold-item-0009` — received a full 7-member panel; `gold-item-0017` received 1 of 7) plus 2 of the routed adjudications. The remaining 47 items collected zero decisions and correctly resolved to `agent_panel_invalid` rather than being silently skipped or fabricated.

**What did not happen:** no panel outcome, label, or agreement figure was invented to fill the gap. Every item still reached a defined terminal state, every high-risk item is either adjudicated or held in a non-promotable state (`unresolved` or `owner_review_required`), and `pnpm agent-review:validate` reports `passed_with_incomplete_pilot` — every safety-critical gate passes; only the informational "did every panel finish" flag is false, and it says so explicitly.

See `agent-review-pilot-report.json` for the full metric set computed from this real partial data.
