# Reviewer packet leakage summary

All 316 blinded reviewer packets built for the 52-item pilot (plus the packets built for the 10-item repeat-stability subset) were scanned for 18 forbidden markers (hidden predictions, gold labels, peer-decision ids, adjudication ids, amendment history, the raw `gold-item-` identifier, and related fields). **Leakage found: 0.** This check runs automatically in `scripts/build-agent-review-packets.mjs` before any packet is used, and is re-verified by `pnpm agent-review:validate`.
