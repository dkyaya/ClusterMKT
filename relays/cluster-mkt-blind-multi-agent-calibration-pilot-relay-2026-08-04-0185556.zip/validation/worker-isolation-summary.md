# Worker isolation summary

29 real, isolated reviewer decisions and 2 real isolated adjudications were collected across a Workflow-orchestrated set of Claude Agent SDK subagent calls (one call per item/role pair, one further call per routed adjudication). All 7 reviewer pseudonyms (`reviewer-alpha` through `reviewer-golf`) were used across the run.

Every collected decision and adjudication payload is checked against the forbidden-marker list (see `reviewer-packet-leakage-summary.md`) and contains no reference to another worker's answer, a pipeline prediction, or a gold label — each subagent call started with zero shared memory and received only its own blinded packet.

**Known limitation, recorded honestly:** isolation here is content isolation plus explicit instruction, not a hard tool sandbox — the calling mechanism does not expose a parameter to revoke a spawned subagent's tool access. See `worker-capability-assessment.md` for the full assessment. This did not surface as a real leakage event in this run (0/316 packets flagged), but it is the precise boundary of what "isolation" means in this environment and should not be overstated.
