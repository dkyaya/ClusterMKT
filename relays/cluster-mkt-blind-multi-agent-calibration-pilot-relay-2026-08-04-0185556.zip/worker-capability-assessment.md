# Worker orchestration capability assessment

Date: 2026-07-31

## Available mechanisms

- **Agent tool** — spawns a subagent with a fresh, isolated context (no memory of the parent
  conversation or of other agent calls). Suitable for one-off isolated reviewer/adjudicator calls.
- **Workflow tool** — orchestrates many `agent()` calls deterministically (`pipeline`/`parallel`),
  with per-call structured-output schemas validated at the tool-call layer. Concurrency is capped
  at `min(16, cpu cores - 2)`; total agent count per workflow run is capped at 1000. This is the
  mechanism used to run the 52-item, panel-of-3/5/7 pilot (expected 200+ reviewer decisions plus a
  separate adjudicator pass and a 10-item repeat-stability pass).

Both mechanisms give genuine content isolation: each `agent()` call starts with zero shared memory,
so a reviewer worker cannot see another worker's answer, the coordinator's preference, or prior
answers for the same item unless the coordinator's prompt explicitly includes them (which this
implementation does not do).

## Real limitation: no hard tool sandbox

Neither `Agent` nor `Workflow`'s `agent()` exposes a parameter to strip a spawned subagent's tool
access (no read-only / no-file-access mode is available for these calls). This means isolation here
is **content isolation plus instruction**, not a hard sandbox:

- Packets never contain the internal `gold-item-XXXX` identifier, a repository file path, or any
  string that would let a worker locate hidden-prediction or gold-label data even if it chose to
  search the repository. Blinded packet IDs are opaque hashes.
- Every worker prompt explicitly instructs the agent not to read repository files and to answer
  only from the evidence supplied in the prompt.
- This is enforced by instruction and by the absence of any leaked identifier — not by revoking the
  subagent's tool permissions, because the harness does not expose that control for this call shape.

This is recorded honestly per the task's hard constraint against fabricating worker isolation.
Worker spawning itself is fully available, so the pilot runs for real; the caveat above is the
precise boundary of what "isolation" means in this environment.

## Conclusion

Worker orchestration is available. The pilot will run with real isolated subagent calls through the
Workflow tool, not simulated in a single shared context.
