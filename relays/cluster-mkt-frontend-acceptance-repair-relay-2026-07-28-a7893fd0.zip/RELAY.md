# Cluster MKT™ frontend-acceptance repair relay

## Objective

Repair the bounded frontend acceptance issues reported after manual review without redesigning the approved application, connecting live services, or changing the locked brand masters. This relay documents implementation commit `a7893fd0094cfe5bd107c05ccfcfb94ce8140fa0`.

## User-reported issues

The global search was disabled; mobile lacked convenient Profile and Settings access; the mobile search row consumed space while scrolling; the global Daily Brief could not be dismissed; Story Cluster actions did not deep-link to a tab; and the Listen panel reused the global brief instead of a cluster-specific audio concept.

## Starting state

`main` and `origin/main` both started at `f086c46e5fc2bf70cae94266583344f621d87a0b`. The workspace was clean except for a redundant untracked nested clone at `ClusterMKT/`; inspection confirmed the same remote and commit, a clean nested worktree, and no dangling objects before it was removed. Baseline Vitest passed 25/25 tests across 8 files. Pre-change Git, tree, test, and locked-master evidence is in `validation/`.

## What changed

Implemented a controlled and honest search form, a responsive profile menu, thresholded mobile search-row collapse, safe session-scoped Daily Brief dismissal, URL-controlled cluster tabs, and separate global versus cluster audio previews. Focused tests cover keyboard, pointer, persistence, URL, responsive, reduced-motion, and accessible-state contracts. Documentation now describes the actual prototype behavior.

## Exact files created

- `apps/web/src/__tests__/ClusterTabRouting.test.tsx`
- `apps/web/src/__tests__/DailyBriefPlayer.test.tsx`
- `apps/web/src/__tests__/GlobalSearch.test.tsx`
- `apps/web/src/__tests__/ProfileMenu.test.tsx`
- `apps/web/src/__tests__/useCollapsibleSearchHeader.test.tsx`
- `apps/web/src/components/audio/ClusterAudioBriefPreview.tsx`
- `apps/web/src/components/audio/DailyBriefPlayer.tsx`
- `apps/web/src/components/navigation/ProfileMenu.tsx`
- `apps/web/src/components/search/GlobalSearch.tsx`
- `apps/web/src/hooks/useCollapsibleSearchHeader.ts`
- `apps/web/src/lib/dailyBrief.ts`
- `scripts/build_frontend_acceptance_repair_relay.py`

## Exact files modified

- `README.md`
- `apps/web/src/__tests__/App.test.tsx`
- `apps/web/src/__tests__/StoryClusterCard.test.tsx`
- `apps/web/src/app/AppShell.tsx`
- `apps/web/src/components/layout/EditionHeader.tsx`
- `apps/web/src/components/story/StoryClusterCard.tsx`
- `apps/web/src/components/story/StoryClusterTabs.tsx`
- `apps/web/src/pages/ClusterDetailPage.tsx`
- `apps/web/src/pages/SettingsPage.tsx`
- `apps/web/src/pages/TodayPage.tsx`
- `apps/web/src/styles/global.css`
- `apps/web/src/styles/layout.css`
- `apps/web/src/test/setup.ts`
- `docs/architecture/APPLICATION_FOUNDATION.md`
- `docs/development/LOCAL_DEVELOPMENT.md`
- `packages/ui/src/__tests__/Tabs.test.tsx`
- `packages/ui/src/components/Tabs.tsx`
- `scripts/README.md`

## Exact files moved

- None.

## Exact files deleted

- `apps/web/src/components/audio/BriefPlayerPreview.tsx`

The deleted `BriefPlayerPreview.tsx` was superseded by purpose-specific Daily Brief and Cluster Audio components. The separate untracked `ClusterMKT/` nested clone was redundant local duplication, not project source; it was verified and removed before implementation.

## Search behavior

Search now accepts typing and paste, has a programmatic label and clear control, clears with Escape, ignores empty submission, and reports that indexing is disconnected. It never filters fixtures or fabricates results and does not persist a query.

## Mobile profile access

A neutral `CM` avatar button is present in the Edition header at every viewport. Its accessible menu links to Profile, Settings, and Appearance, represents current routes, closes with Escape or outside pointer input, and returns focus to the trigger on dismissive closure. Authentication and Sign Out remain absent.

## Header-collapse behavior

The primary identity/status/profile row remains sticky. On viewports at or below 800 px, the search row starts visible, hides after 24 px of accumulated downward movement, restores after 12 px upward or within 16 px of the top, and stays visible while search is focused or the profile menu is open. The listener is passive and cleaned up; desktop never collapses; reduced-motion CSS disables movement transitions.

## Daily Brief dismissal behavior

The global Daily Brief supports a labeled close button, Escape from within the card, and left/right touch or mouse pointer drag. Horizontal gestures coexist with native vertical scrolling, use a 72–96 px/30% threshold, and unsuccessful drags reset. Safe `sessionStorage` keys include the America/New_York market date and edition, so dismissal does not suppress the next edition or market date. Storage denial does not break rendering.

## Tab deep-link behavior

Card title and Overview, Read, and Listen actions target `?tab=overview`, `?tab=read`, and `?tab=listen`. Cluster detail derives state from the URL, defaults invalid or missing values to Overview, updates the URL on tab selection, and restores the rendered tab through refresh and browser history. Shared Tabs now supports controlled state without breaking uncontrolled use.

## Audio-component separation

`DailyBriefPlayer` remains global and describes the followed-market universe. `ClusterAudioBriefPreview` receives the active cluster ID and title and appears only above that cluster's related podcasts. The cluster Listen panel does not contain “Daily market brief.” Both controls explicitly say generated audio is unavailable.

## Accessibility work

Search has a label, polite status, native search semantics, and keyboard clearing. Profile uses button/menu/menuitem semantics, Escape, outside dismissal, route state, and focus return. Tabs preserve roles, selected state, roving tab stops, arrow/Home/End behavior, and controlled/uncontrolled APIs. Dismissal labels include the active edition. Reduced-motion behavior is explicit.

## Tests added

Vitest now passes 56/56 behavior tests across 13 files, up from 25/25 across 8. New coverage includes search, profile, header thresholds and cleanup, Daily Brief storage and gestures, direct tab URLs/history, audio-context separation, and controlled Tabs compatibility.

## Visual validation

Vite started successfully at `http://127.0.0.1:5173`. The installed in-app browser control surface reported that no controllable browser was available, so screenshots and manual pointer screenshots could not be captured. No new browser/test dependency was installed solely for images. Component interaction tests, responsive CSS assertions, and the production web build provide the available local evidence; see `previews/README.md` and `validation/interaction-validation.md`.

## Validation commands

```sh
pnpm install --frozen-lockfile
pnpm format:check
pnpm lint
pnpm typecheck
pnpm test:run
pnpm build
pnpm brand:validate
pnpm foundation:validate
pnpm validate
python scripts/build_frontend_acceptance_repair_relay.py
```

## Validation results

- Formatting: PASS.
- ESLint: PASS with zero warnings.
- Strict TypeScript: PASS across all five workspaces.
- Tests: PASS, 56/56 across 13 files.
- Web production build: PASS, 173 modules and canonical dimensional SVGs bundled.
- Worker Wrangler dry-run build: PASS, no bindings and no deployment.
- Brand validation: PASS, 11/11 groups.
- Foundation validation: PASS, 24/24 checks.
- Locked masters: PASS, 5/5 exact SHA-256 matches.
- `git diff --check`: PASS.

## Failures and repairs

- Two first-pass focused tests exposed incorrect test setup around the top threshold and asynchronous focus restoration; fixtures were corrected while preserving the implementations.
- The first full validation run found formatting drift after the last test addition; formatting was applied and rechecked.
- The next run caught an unsafe Node global in a CSS-contract test; the test moved to explicit filesystem resolution.
- TypeScript then required explicit Node test types for those imports; a file-scoped type reference fixed it without relaxing application strictness.
- The final complete validation passed. No test, lint rule, type setting, or other gate was weakened.

## Implementation commit

`a7893fd0094cfe5bd107c05ccfcfb94ce8140fa0` — `Refine Cluster MKT prototype interactions` on `main`.

## Push result

The implementation commit was pushed non-destructively to `origin/main`; no force push was used. Exact Git and remote evidence is in `validation/push-result.txt` and `validation/git-log-after-implementation.txt`.

## What remains demonstration-only

Search indexing, results, all story/source/podcast fixtures, Daily Brief audio, cluster audio, profile/account state, settings persistence, authentication, live ingestion, financial data, publisher connections, AI, and TTS remain disconnected.

## Remaining uncertainties

No browser screenshots were available in this environment. Product-owner retesting on representative iOS/Android and desktop browsers remains appropriate, especially for tactile swipe feel and device safe areas. The final editorial serif and inherited brand/legal approval items remain open.

## Remaining blockers

No implementation, validation, commit, or push blocker remains.

## Recommended next phase

Proceed with the bounded source-foundation phase: publisher/feed capability matrix, canonical source metadata, entity-resolution dictionary, relevance-scoring corpus, Story Cluster fixture set, and adversarial ticker-collision cases. Keep it offline and fixture-driven with no live ingestion.

## Reproduction commands

```sh
pnpm install --frozen-lockfile
pnpm validate
python scripts/build_frontend_acceptance_repair_relay.py
```

## SHA-256 hashes

- `cluster-mkt-mark-dimensional-light.svg` — `66496cfe8dc2d6abb51c5b5a58824ca751db2de0d9a65be621f083bc075b11a1`
- `cluster-mkt-mark-dimensional-dark.svg` — `b8c4d7a36ae24daf5bb6e785dc41d9e6c4b01649e5eb5c55959763b5faa3405b`
- `cluster-mkt-mark-flat.svg` — `2dfae7aaf3524a80fe86a56f2fb3a1fa01b866c55abf11e3faf86aa6ef8ca992`
- `cluster-mkt-mark-monochrome-black.svg` — `037232276468c91ce7bb70daac33bc615f83ee3942855d4bd7b337e074fe5850`
- `cluster-mkt-mark-monochrome-white.svg` — `b676c0856aaa5b0c2bca0a687df8519b5c2c069044fa2e40ce0605c44b703542`

## Suggested Codex profile for the next phase

Heavy — GPT-5.6 Sol High.

## PLAIN-ENGLISH TRANSLATION

Users can now type, paste, clear, and submit search text; the app responds honestly that search is not connected. On mobile, the profile button makes Profile and Settings easy to reach, while the search row gets out of the way during downward scrolling and comes back when the user scrolls up.

The global Daily Brief can be closed or swiped away and stays dismissed only for that market date and edition in the current browser session. Story cards now open the exact Overview, Read, or Listen section requested, and browser Back/Forward preserves that choice. The Listen page now shows audio for that one Story Cluster conceptually—not a second copy of the whole-market Daily Brief.

Nothing was connected to live search, live news, accounts, AI, or audio generation. The public GitHub `main` branch received the tested implementation. Next, build the offline source registry and aggressive relevance/clustering fixture corpus before connecting publishers.
