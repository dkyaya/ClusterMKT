# Moved and deleted paths

## Moved

- None.

## Deleted

- `apps/web/src/components/audio/BriefPlayerPreview.tsx`
