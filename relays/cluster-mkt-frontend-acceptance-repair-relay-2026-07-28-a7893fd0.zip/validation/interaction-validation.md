# Interaction validation

Overall status: **PASS with screenshot limitation**.

- Global search behavior: PASS through controlled-form tests (type, clear, Escape, empty/nonempty submission, accessible label, no fabricated results).
- Profile behavior: PASS through button/menu semantics, link, Escape, outside-pointer, route-state, and focus-return tests.
- Mobile search collapse: PASS through top/down/up/hysteresis/focus/menu/desktop/cleanup tests and reduced-motion CSS assertion.
- Daily Brief: PASS through button, Escape, persistence, edition/date, safe-storage, pointer-threshold, and failed-drag reset tests.
- Direct tab routing: PASS for Read, Listen, missing/invalid fallback, URL update, history restoration, card actions, and controlled/uncontrolled Tabs.
- Audio separation: PASS; the cluster Listen panel has cluster context and excludes “Daily market brief,” while the global Daily Brief remains in AppShell.
- Production browser bundle: PASS.
- Local Vite server: PASS at `http://127.0.0.1:5173` and then stopped cleanly.
- Screenshot capture: NOT AVAILABLE. The installed in-app browser control surface returned “No browser is available.” No substitute browser stack was added solely for screenshots.
