# Cluster MKT gold-calibration corpus and reviewer-workflow relay

## Relay identity

- Phase: gold-calibration corpus and reviewer workflow
- Prepared: 2026-07-31 (America/New_York)
- Repository: `https://github.com/dkyaya/ClusterMKT`
- Branch: `main`
- Foundation parent: `7358a6f536a4384174636c350b80624ebd9ed36e`
- Implementation commit: `a14d2eadbd9df685e6a17a3d51c81031acb288b1`
- Implementation subject: `Build gold calibration corpus and reviewer workflow`
- Implementation push: successful (`7358a6f..a14d2ea`, `main -> main`)
- Corpus version: `gold-corpus-v1`
- Corpus SHA-256: `b5805eabd6d8c1a28d8104735c9dae69ebf07bb11ba4fa10cf8665cedd64a549`
- Suggested Codex profile: Heavy — GPT-5.6 Sol High

## Executive result

The implementation establishes an offline, deterministic, human-review-centered calibration foundation. It supplies 345 task items, annotation contracts, blinded assignment and submission controls, adjudication and amendment contracts, agreement metrics, leakage-safe group partitioning, threshold-calibration scaffolding, held-out replay gates, focused regression-promotion rules, an offline CLI, and developer-only review pages.

The software and corpus safety gates pass. The corpus is deliberately **not** represented as human-labeled gold: it contains zero reviewer decisions, zero adjudications, and zero final gold labels until real independent reviewers use the workflow. Agreement, threshold selection, held-out performance, and regression promotion therefore report `BLOCKED_PENDING_HUMAN_REVIEW` rather than synthetic values.

Controlled-browser validation is also not complete. The local Vite server and browser runtime setup succeeded, but browser discovery returned `[]`; no controlled browser was available to inspect the required routes. Component tests and builds pass, but visual acceptance, screenshots, console inspection, network inspection, and traces are not claimed.

## Corpus design

Each stable corpus item records corpus version, fixture/raw/normalized identifiers, one annotation task, sampling dimensions, difficulty, evidence depth, source and event properties, sector/subindustry, ambiguity and duplication classes, visible evidence fields, hidden prediction fields, expected review count, provenance, fixture-use classification, timestamps, amendments, regression status, and exclusion status.

Final labels cannot be silently replaced. Any correction requires an append-only amendment that cites the prior value, new value, reason, actor, and timestamp. Pipeline output is never accepted as a substitute for human judgment.

## Annotation tasks

The task contract defines label definitions, positive and negative examples, edge cases, insufficient-evidence and cannot-determine paths, confidence, notes, and escalation for:

- Source normalization: canonical relationships, duplicates, format variants, syndication, independent reporting, updates, new underlying work, and quarantine.
- Entity resolution: candidates, acceptance/rejection, direct versus inferred mentions, mention type, ticker ambiguity, topical fit, and review routing.
- Event boundaries: same/related/separate events, updates, corrections, proposal versus final action, rumor versus confirmation, and multi-event records.
- Story-cluster membership: accepted, related context, rejected, review required, and quarantined.
- Claim evidence: presence, fact versus interpretation, claim type, evidence depth, supporting field/span, quantities, attribution, and support status.
- Agreement/disagreement: equivalent, compatible, contradictory, temporal/scope/quantitative/interpretive differences, apparent disagreement, and supersession.
- Review routing: accepted, review required, rejected, quarantined, display and Sector Brief eligibility, and blocking reason.
- Sector coverage: sector-wide, company-led sector impact, macro-to-sector, company-specific, inclusion, materiality, subindustry impact, and anti-concentration relevance.

Objective labels are kept distinct from evidence-limited or judgment-based labels so agreement metrics can be selected by label type instead of collapsed into one accuracy number.

## Sampling and coverage

The deterministic candidate corpus contains 345 task items:

| Task | Items | Minimum | Result |
| --- | ---: | ---: | --- |
| Source normalization | 45 | 40 | Pass |
| Entity resolution | 60 | 50 | Pass |
| Event boundaries | 45 | 40 | Pass |
| Story-cluster membership | 45 | 40 | Pass |
| Claim evidence | 55 | 50 | Pass |
| Agreement/disagreement | 35 | 30 | Pass |
| Sector coverage | 30 | 25 | Pass |
| Review routing | 30 | 25 | Pass |

Cross-cutting strata also pass: 40 ticker traps, 30 duplicate/syndication cases, 30 article-version cases, 35 metadata-limited cases, 25 podcast cases, 30 quantitative-claim cases, 25 apparent-disagreement cases, and 25 evolving-event cases. NVIDIA represents 10% of company-specific items, below the 15% ceiling.

Fixtures are synthetic or repository-permitted structured representations. They contain no fetched premium full text, private-market entities, investment recommendations, AI-generated annotations, or live publisher data.

## Reviewer workflow and blinding

Local fixture identities use four roles: `reviewer`, `senior_reviewer`, `adjudicator`, and `corpus_manager`. Authentication is intentionally not implemented.

Initial reviewer views expose permitted evidence and provenance but remove pipeline predictions, other reviewers' decisions, and adjudication results. Items can be deterministically ordered or seeded-randomized. Gold candidates require at least two independent reviews; designated high-risk classes can require three. Duplicate submissions from one reviewer are rejected. Decisions, timestamps, notes, confidence, and amendments are append-only.

The developer-only routes are `/dev/review`, `/dev/review/:itemId`, and `/dev/adjudication`. They use local demonstration state, are absent from consumer navigation, and make no live-source or authentication claim.

## Adjudication

Disagreement, low confidence, cannot-determine decisions, high-risk labels, critical evidence rules, later material system disagreement, and gold amendments are routed to adjudication. Adjudication records final label, reason, cited evidence, decisions considered, guideline/threshold follow-up flags, regression recommendation, confidence, adjudicator, and timestamp.

Critical factual and provenance decisions cannot be resolved by simple majority alone. Difficult examples and unresolved disagreements remain visible; they are not deleted to improve reported metrics.

## Inter-rater agreement

The implementation supports raw agreement, Cohen's kappa, Fleiss' kappa, weighted kappa, precision/recall against adjudicated gold, confusion matrices, cannot-determine rate, review-required rate, and confidence distributions. Reports can be segmented by task, label, difficulty, source category, evidence depth, sector, and reviewer pair. Metrics are omitted where mathematically inappropriate.

Current measured state:

- Reviewer decisions: 0
- Reviewed items: 0
- Reviewer pairs: 0
- Adjudications: 0
- Final gold labels: 0
- Agreement and kappa: not measurable
- Fabricated values: 0

This is the correct pre-review result. The 0.85 raw-agreement and 0.70 core-kappa gates can only be evaluated after independent human review.

## Dataset partitioning

Partitioning is deterministic and groups by event or underlying work rather than URL:

- Training/development: 207 items (60%)
- Calibration: 69 items (20%)
- Held-out evaluation: 69 items (20%)
- Underlying-work groups: 115
- Leaking groups: 0

Article versions, syndicated copies, same-event records, and near-duplicate source packages stay together. Held-out labels and scores remain unavailable to calibration logic.

## Threshold calibration

`calibration-v1` defines ten threshold families: URL near-duplicate, syndication, article version, entity acceptance, ticker disambiguation, event similarity, cluster membership, claim equivalence, sector materiality, and review routing. Each version records corpus versions, objectives, old and candidate thresholds, alternatives, tradeoffs, metrics, and approval state.

Current result is intentionally blocked: there are zero adjudicated calibration labels and zero matching observations, so there are zero proposed changes and zero automatically applied changes. Critical precision, zero ambiguous-ticker false positives, zero unsupported visible claims, and avoidance of false sector-wide promotion remain hard objectives.

## Held-out replay

The replay contract reserves 69 held-out items but correctly scores zero items until human gold labels exist. Existing invariant checks report zero for:

- Unsupported visible claims
- Podcast-metadata factual evidence
- Syndicated-source inflation
- Accepted ambiguous-ticker false positives
- Accepted claims without provenance
- Quarantined-evidence leakage
- Unexplained record loss
- Company-specific false sector-wide promotion
- Unadjudicated critical disagreements
- Unversioned gold labels

These zeros validate the fixture and gate plumbing; they are **not** claims of held-out predictive performance.

## Regression promotion

Promotion requires a finalized human gold label, complete provenance, no unresolved reviewer disagreement, repository-permitted fixture use, stable deterministic behavior, a meaningful edge case or prior failure, and clear expected output. Current results are 0 eligible, 0 promoted, and 345 blocked pending human review. This avoids turning every corpus item into an ordinary test or prematurely enshrining unreviewed labels.

## API-key and source-onboarding readiness

No credential was obtained. `.env.example` contains only three empty names: `NYT_API_KEY`, `SPOTIFY_CLIENT_ID`, and `SPOTIFY_CLIENT_SECRET`.

- No key expected: SEC public data APIs; approved public RSS/Atom and podcast RSS; Spotify embeds/oEmbed; permitted company and government feeds.
- Key or OAuth may be required: New York Times developer API; Spotify Web API beyond embeds; other formally reviewed developer APIs.
- Commercial agreement may be required: premium financial-news datasets, licensed full text, real-time market data, and commercial transcript services.

The documented 11-step source gate requires documentation and terms review, field/limit/cost/credential recording, dry-run adapter implementation, out-of-Git secret storage, explicit bounded smoke-test authorization, reconciliation review, and explicit enablement. Nothing becomes live automatically.

## Validation result

`pnpm validate` passed on the implementation state. It covered formatting, linting, strict TypeScript, 35 test files and 357 tests, all deterministic source/entity/event/cluster/claim/discourse/provenance/registry/adapter/ingestion gates, the 10-test gold-calibration project, web and Worker builds, brand validation, and all 24 foundation checks.

Focused corpus commands passed their executable safety gates:

- `pnpm corpus:validate`: PASS; 345 items; required strata satisfied; no automated gold labels.
- `pnpm corpus:agreement`: PASS contract; correctly blocked pending human decisions.
- `pnpm corpus:calibrate`: PASS contract; correctly blocked pending adjudicated labels/scores; no applied threshold.
- `pnpm corpus:replay`: PASS critical invariant plumbing; correctly blocked from held-out performance claims.

Additional integrity checks:

- `.env.example` values are empty.
- Boundary-aware secret-token scan found no matches.
- Phase implementation scan found no fetch, XHR, Axios, or HTTP URL in executable corpus/reviewer code.
- No dependency or lockfile was added or changed.
- All five locked brand-master hashes match the baseline.
- `AGENTS.md` is 105 lines, below 200.
- The implementation has 96 files: 77 created, 19 modified, 34,062 insertions, and 4 deletions.

Full output and machine-readable reports are under `validation/`. Exact implementation files are under `changed-files/`. The authoritative inventory is `validation/changed-files.txt`, and `file-hashes.sha256` authenticates every relay payload file other than itself.

## Browser result and previews

Status: **BLOCKED — acceptance not established**.

The required routes and desktop/mobile viewports were not inspected because the supported controlled-browser discovery returned no available browser. The relay therefore contains no screenshots or trace. `previews/README.md`, `validation/browser-validation-results.md`, `validation/browser-console.txt`, and `validation/browser-network.txt` record the exact scope.

Component tests and builds passed, but they do not replace browser acceptance. This is the only execution blocker in this relay.

## Failures and repairs during implementation

- Fixture regeneration originally exposed formatting drift. The generator was repaired to invoke the repository's existing Prettier tool, so deterministic regeneration is formatting-clean without a new dependency.
- Agreement/calibration/replay reports were kept blocked when no human labels existed; fabricated placeholder scores were not introduced.
- Controlled-browser setup succeeded, but browser discovery returned `[]`. No source-only visual acceptance was substituted.

## Exact files changed

The implementation commit contains exactly 96 paths. Their repository-relative copies are preserved one-for-one under `changed-files/`, and their exact line-delimited inventory is in `validation/changed-files.txt`. The changes are organized as follows:

- Root/configuration: `.env.example`, `AGENTS.md`, `README.md`, `package.json`, `vitest.workspace.ts`.
- Web: 17 reviewer-workbench route, page, component, data, test, style, and README paths.
- Documentation: 25 architecture, product, decision, development, reviewer, and package/pipeline/test documentation paths.
- Config package: 7 annotation, sampling, partition, threshold, credential, export, and README paths.
- Core package: 35 schema, type, workflow, agreement, adjudication, calibration, partition, promotion, export, and README paths.
- Scripts: 9 corpus fixture, CLI, evaluation, calibration, replay, promotion, and shared evaluation paths.
- Tests/fixtures: 8 corpus fixture and gold-calibration test paths.

No dependency was added.

## Reproduction commands

Run from repository root at implementation commit `a14d2ea`:

```sh
pnpm install --frozen-lockfile
pnpm corpus:validate
pnpm corpus:agreement
pnpm corpus:partition
pnpm corpus:calibrate
pnpm corpus:replay
pnpm corpus:report
pnpm validate
pnpm dev:web
```

With a controlled browser available, inspect `/dev/review`, `/dev/review/gold-item-0001`, and `/dev/adjudication` at 1440 × 1000 and 390 × 844; verify blinding before submission, cannot-determine and confidence controls, adjudication comparison, metrics/coverage/partition data, no consumer navigation exposure, no horizontal overflow, and console/network cleanliness.

## Commit and push status

- Implementation commit: pushed successfully to `origin/main`.
- Relay commit: necessarily created after this archive; its hash and push result belong in the final handoff, not retroactively inside the immutable ZIP.
- Force push: not used.

## Remaining uncertainty and recommended next phase

Use **Path A: calibration repair / human-review execution**, not a live-source pilot yet.

The next phase should recruit fixture-safe human reviewers, run blinded double review (three for selected high-risk cases), adjudicate every disagreement, amend guidelines without deleting hard examples, then calculate task-appropriate agreement. Only after finalized labels exist should calibration observations be produced, thresholds proposed on the calibration partition, and critical held-out gates evaluated. Browser validation must also be rerun with a working controlled-browser backend.

A bounded live-source pilot is not authorized by this evidence because human agreement and held-out performance remain unmeasured. When those gates pass, a later pilot should favor SEC public data and one or two formally approved public feeds, with a small item cap and manual review before display.

## Plain-English translation

Humans will review small, permitted evidence packages and answer focused questions: whether two records are copies or updates, whether an entity mention is real, whether records concern the same event, whether a source belongs in a cluster, whether a claim is actually supported, whether two claims agree, how an item should be routed, and whether it truly has sector-wide importance.

Two independent reviewers are required because one person's confident judgment is not enough to create a trustworthy benchmark. Reviewers submit without seeing the pipeline's guess or each other's answers. If they disagree, the disagreement stays in the record and a qualified adjudicator resolves it from cited evidence; critical facts are not decided by a vote alone.

Thresholds are tuned only after humans finalize labels. Related copies and versions stay in the same data partition so the system cannot accidentally study an event and then be tested on a near-copy. Development data supports iteration, calibration data selects thresholds, and untouched held-out data decides whether the system is safe enough to advance.

No API key was obtained and no live source was connected. SEC and approved public feeds often need no key. The New York Times developer API and advanced Spotify API access may need developer credentials. Premium financial news, real-time market data, licensed full text, and commercial transcripts may need paid licensing. Every source still needs formal documentation, terms, capability, cost, secret-storage, dry-run, smoke-test, and explicit-enablement review.

Everything in this phase remains offline. The immediate next work is real blinded human review plus adjudication and browser acceptance—not live ingestion.

