# Corpus partition summary

- Status: PARTITIONED_AWAITING_LABELS
- Summary: Items are split deterministically by event or underlying-work group, never by URL.
- training: 207
- calibration: 69
- held_out: 69
- groupCount: 115
- leakingGroupCount: 0
- Safety gates: PASS
- Blockers: Held-out outcomes remain unavailable until independent human labels are finalized.
