# Adapter contract evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- contractCompliance: 1
- rawSchemaCompliance: 1
- provenanceCompleteness: 1
- cursorCorrectness: 1
- checkpointCorrectness: 1
- unsupportedContentHandling: 1
- errorShapeCompliance: 1
- Critical failures: 0
- Result: PASS
