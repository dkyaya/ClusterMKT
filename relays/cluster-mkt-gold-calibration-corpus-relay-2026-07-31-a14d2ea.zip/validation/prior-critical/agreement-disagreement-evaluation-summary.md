# Agreement and disagreement evaluation summary

- Mode: offline, deterministic, fixture-driven
- Agreement / disagreement cases: 5 / 9
- Syndicated-source inflation: 0
- False consensus: 0
- False disagreement: 0
- Superseded-claim violations: 0
- Critical failures: 0
- Result: PASS
