# Claim evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 20
- Metadata-only detailed violations: 0
- Podcast-metadata factual-evidence violations: 0
- Unsupported visible claims: 0
- Provenance gaps: 0
- Critical failures: 0
- Result: PASS
