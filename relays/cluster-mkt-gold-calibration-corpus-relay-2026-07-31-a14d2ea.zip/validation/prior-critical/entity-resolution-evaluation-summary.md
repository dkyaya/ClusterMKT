# Entity-resolution evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 23
- Explicit ticker-collision fixtures: 5
- Extended ordinary-language assertions: 29
- Accepted ticker false positives: 0
- Explanation-code gaps: 0
- Private-market entities: 0
- Critical failures: 0
- Result: PASS
