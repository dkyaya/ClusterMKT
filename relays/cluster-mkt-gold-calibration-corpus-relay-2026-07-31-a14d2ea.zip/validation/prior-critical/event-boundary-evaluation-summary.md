# Event-boundary evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 15
- Same-event / distinct-or-related / review-required: 2 / 10 / 1
- Company-and-date-only merges: 0
- Headline-only update splits: 0
- Critical failures: 0
- Result: PASS
