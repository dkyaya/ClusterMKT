# Ingestion idempotency evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- exactReplayDuplicatesCreated: 0
- duplicateRawRecordsCreated: 0
- duplicateAcceptedClusters: 0
- duplicateSectorBriefs: 0
- articleVersionCorrectness: 1
- collisionDetection: 1
- rulesVersionReprocessingCorrectness: 1
- Critical failures: 0
- Result: PASS
