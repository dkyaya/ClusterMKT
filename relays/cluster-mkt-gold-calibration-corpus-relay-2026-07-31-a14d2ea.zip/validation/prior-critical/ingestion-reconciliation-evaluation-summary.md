# Ingestion reconciliation evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- rawRecordAccountingCompleteness: 1
- terminalStateExclusivity: 1
- downstreamCountConsistency: 1
- clusterAccounting: 1
- claimAccounting: 1
- sectorBriefAccounting: 1
- provenanceFailureAccounting: 1
- unexplainedLoss: 0
- Critical failures: 0
- Result: PASS
