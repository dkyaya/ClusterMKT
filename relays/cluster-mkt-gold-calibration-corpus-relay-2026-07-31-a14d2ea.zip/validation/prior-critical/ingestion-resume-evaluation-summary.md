# Ingestion resume evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 3
- checkpointCorrectness: 1
- duplicateOutputsAfterResume: 0
- finalOutputEquivalence: 1
- interruptedRunTraceability: 1
- resumeTokenValidity: 1
- Critical failures: 0
- Result: PASS
