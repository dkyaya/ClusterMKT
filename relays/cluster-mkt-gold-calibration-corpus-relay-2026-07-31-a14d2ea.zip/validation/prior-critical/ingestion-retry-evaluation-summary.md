# Ingestion retry evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- retryableClassificationAccuracy: 1
- nonRetryableClassificationAccuracy: 1
- retryCountCorrectness: 1
- retryAfterCorrectness: 1
- circuitBreakerCorrectness: 1
- infiniteRetries: 0
- Critical failures: 0
- Result: PASS
