# Offline ingestion end-to-end evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- validSourceToSectorBriefPath: 1
- quarantineLeakage: 0
- reviewRoutingAccuracy: 1
- syndicatedSourceInflation: 0
- podcastEvidenceViolations: 0
- realNetworkCalls: 0
- unauthorizedSourceActivations: 0
- rawToBriefProvenanceCompleteness: 1
- Critical failures: 0
- Result: PASS
