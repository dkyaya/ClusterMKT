# Provenance evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 7
- Accepted-claim path gaps: 0
- Sector Brief path gaps: 0
- Quarantined-evidence violations: 0
- Broken accepted references: 0
- Critical failures: 0
- Result: PASS
