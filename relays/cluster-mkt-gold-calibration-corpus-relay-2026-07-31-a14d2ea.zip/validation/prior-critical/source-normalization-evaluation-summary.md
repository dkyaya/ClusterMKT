# Source-normalization evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 42
- Exact duplicate / syndication / version: 4 / 6 / 7
- Syndicated copies counted as independent: 0
- Independent reports lost: 0
- Provenance gaps: 0
- Critical failures: 0
- Result: PASS
