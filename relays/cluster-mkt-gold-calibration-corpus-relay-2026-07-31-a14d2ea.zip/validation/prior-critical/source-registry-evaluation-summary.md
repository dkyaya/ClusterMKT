# Source registry evaluation summary

- Mode: offline, deterministic, fixture-driven
- Cases: 50
- schemaValidity: 1
- sourceCount: 10
- duplicateSourceIds: 0
- duplicateSourceFamilyIds: 0
- invalidCapabilityCombinations: 0
- termsEligibilityViolations: 0
- fixtureEnabledSources: 9
- liveReadySources: 0
- Critical failures: 0
- Result: PASS
