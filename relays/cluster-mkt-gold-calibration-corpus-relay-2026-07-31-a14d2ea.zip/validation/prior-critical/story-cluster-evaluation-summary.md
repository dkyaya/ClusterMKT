# Story Cluster evaluation summary

- Mode: offline, deterministic, fixture-driven
- Rules: normalization-v1
- Cases: 21
- Accepted / review-required / rejected: 12 / 6 / 3
- Same-company/date-only merges: 0
- Display-eligibility violations: 0
- Critical failures: 0
- Result: PASS
