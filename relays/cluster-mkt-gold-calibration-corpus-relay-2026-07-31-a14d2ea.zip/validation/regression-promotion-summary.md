# Regression promotion summary

- Status: BLOCKED_PENDING_HUMAN_REVIEW
- Summary: No candidate is promoted until its human gold label, adjudication, provenance, and fixture-use classification are complete.
- corpusItems: 345
- goldLabels: 0
- eligibleForPromotion: 0
- promoted: 0
- blocked: 345
- Safety gates: PASS
- Blockers: Human gold labels and adjudications are pending.
