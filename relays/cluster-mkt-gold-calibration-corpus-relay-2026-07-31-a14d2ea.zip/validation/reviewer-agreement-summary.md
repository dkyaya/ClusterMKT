# Reviewer agreement summary

- Status: BLOCKED_PENDING_HUMAN_REVIEW
- Summary: Agreement is intentionally not calculated until at least two independent human decisions exist for candidate items.
- reviewerDecisions: 0
- reviewedItems: 0
- reviewerPairs: 0
- adjudications: 0
- rawAgreement: not measurable
- objectiveBinaryRawAgreement: not measurable
- cohensKappa: not measurable
- fleissKappa: not measurable
- weightedKappa: not measurable
- cannotDetermineRate: not measurable
- reviewRequiredRate: not measurable
- fabricatedAgreementValues: 0
- goldLabels: 0
- Safety gates: PASS
- Blockers: Two independent human reviews per candidate are required before agreement metrics can be reported.
