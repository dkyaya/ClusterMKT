# Threshold calibration summary

- Status: BLOCKED_PENDING_HUMAN_REVIEW
- Summary: calibration-v1 is defined, but no threshold changes are proposed without adjudicated calibration labels and recorded pipeline scores.
- thresholdCount: 10
- adjudicatedGoldLabels: 0
- calibrationObservations: 0
- proposedThresholdChanges: 0
- automaticallyAppliedChanges: 0
- heldOutCriticalFailures: not measurable
- Safety gates: PASS
- Blockers: Human-reviewed calibration labels and matching pipeline scores do not yet exist.; Held-out scoring cannot occur before labels are finalized.
