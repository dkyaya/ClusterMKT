# Cluster MKT™ repository-foundation relay

## Objective

Prepare the local Cluster MKT repository structurally for a separate website and application scaffolding phase, while integrating the validated brand package and preserving every locked logo master byte-for-byte.

## Starting repository condition

The starting directory contained the complete validated `brand/` package plus 13 loose root-level brand source/export/validation files, two baked-checkerboard development PNGs, `.DS_Store`, and the prior brand relay inside `brand/relay/`. It had no `.git` directory, root README, agent guidance, product/architecture documentation, package-manager manifest, dependency tree, or application code. Consequently, Git tracking state, branch, diff, and history could not be determined; no repository was initialized.

## What changed

- Established an intentional pre-application repository layout with purposeful README-only component boundaries.
- Added concise shared agent rules, Claude import compatibility, product and planned-architecture documentation, three ADRs, root hygiene files, and a reusable foundation validator.
- Consolidated the brand masters, reference exports, and original validation artifacts beneath `brand/source/` and relocated both relay functionality and historical relay storage.
- Removed three adjudicated disposable files and cleaned verification bytecode caches.
- Updated brand tooling and path references, rebuilt the brand package, reran brand validation, and verified all locked hashes.

Counts: **22 repository files created**, **8 existing files modified**, **15 files relocated**, and **3 starting files deleted**. The relay ZIP is one additional created distribution artifact.

## Files created

- `.editorconfig`
- `.gitignore`
- `AGENTS.md`
- `CLAUDE.md`
- `README.md`
- `apps/web/README.md`
- `apps/worker/README.md`
- `docs/architecture/PLANNED_ARCHITECTURE.md`
- `docs/decisions/0001-repository-layout.md`
- `docs/decisions/0002-shared-agent-guidance.md`
- `docs/decisions/0003-brand-assets-are-locked.md`
- `docs/decisions/README.md`
- `docs/product/PRODUCT_FOUNDATION.md`
- `packages/config/README.md`
- `packages/core/README.md`
- `packages/ui/README.md`
- `pipelines/README.md`
- `relays/README.md`
- `scripts/README.md`
- `scripts/build_repo_foundation_relay.py`
- `scripts/validate_repository_foundation.py`
- `tests/README.md`

## Files modified

- `brand/BRAND_GUIDELINES.md`
- `brand/README.md`
- `brand/brand-assets-manifest.json`
- `brand/build_brand_package.py`
- `brand/source/README.md`
- `brand/validation/cluster-mkt-brand-validation-report.json`
- `brand/validation/cluster-mkt-brand-validation-summary.md`
- `brand/validation/validate_cluster_mkt_brand_package.py`

## Files moved

- `cluster-mkt-mark-dimensional-light.svg` → `brand/source/locked-masters/cluster-mkt-mark-dimensional-light.svg`
- `cluster-mkt-mark-dimensional-dark.svg` → `brand/source/locked-masters/cluster-mkt-mark-dimensional-dark.svg`
- `cluster-mkt-mark-flat.svg` → `brand/source/locked-masters/cluster-mkt-mark-flat.svg`
- `cluster-mkt-mark-monochrome-black.svg` → `brand/source/locked-masters/cluster-mkt-mark-monochrome-black.svg`
- `cluster-mkt-mark-monochrome-white.svg` → `brand/source/locked-masters/cluster-mkt-mark-monochrome-white.svg`
- `cluster-mkt-mark-dimensional-light-2048.png` → `brand/source/reference-exports/cluster-mkt-mark-dimensional-light-2048.png`
- `cluster-mkt-mark-dimensional-dark-2048.png` → `brand/source/reference-exports/cluster-mkt-mark-dimensional-dark-2048.png`
- `cluster-mkt-mark-flat-1024.png` → `brand/source/reference-exports/cluster-mkt-mark-flat-1024.png`
- `cluster-mkt-mark-monochrome-black-1024.png` → `brand/source/reference-exports/cluster-mkt-mark-monochrome-black-1024.png`
- `cluster-mkt-mark-monochrome-white-1024.png` → `brand/source/reference-exports/cluster-mkt-mark-monochrome-white-1024.png`
- `cluster-mkt-asset-validation-report.json` → `brand/source/original-validation/cluster-mkt-asset-validation-report.json`
- `cluster-mkt-assets-manifest.md` → `brand/source/original-validation/cluster-mkt-assets-manifest.md`
- `export_and_validate_cluster_mkt_assets.py` → `brand/source/original-validation/export_and_validate_cluster_mkt_assets.py`
- `brand/relay/build_cluster_mkt_brand_relay.py` → `scripts/build_brand_relay.py`
- `brand/relay/cluster-mkt-full-brand-package-relay-2026-07-28-714f2cdc.zip` → `relays/cluster-mkt-full-brand-package-relay-2026-07-28-714f2cdc.zip`

## Files deleted

- `.DS_Store`
- `cluster-mkt-dimensional-reference-light-2048.png`
- `cluster-mkt-vector-deliverables-reference-sheet-2048.png`

See `validation/cleanup-log.md` and `validation/relocation-log.md` for hashes, decisions, and replacement paths.

## Files intentionally left unchanged

- All five locked SVG masters retained their exact bytes; only their canonical paths changed.
- Production brand SVG, PNG, icon, social, motion, and preview assets that did not need path updates remain unchanged.
- `brand/brand-tokens.css` and `brand/brand-tokens.json` remain authoritative.
- The previous full-brand relay remains intact at `relays/cluster-mkt-full-brand-package-relay-2026-07-28-714f2cdc.zip`; it is deliberately not nested in this relay.

## Cleanup rationale

Loose authoritative files were consolidated, not duplicated. The two development references were deleted because they baked in checkerboards and had canonical replacements in the validated package. `.DS_Store` and verification caches had no project value. No indiscriminate archive directory was created, and no ambiguous unique file remained.

## Final repository structure

The root now contains only `.editorconfig`, `.gitignore`, `AGENTS.md`, `CLAUDE.md`, `README.md`, `apps/`, `brand/`, `docs/`, `packages/`, `pipelines/`, `relays/`, `scripts/`, and `tests/`. Application boundaries contain documentation only; no React, Vite, Cloudflare, Supabase, workspace, authentication, database, CI, or deployment files were scaffolded.

## AGENTS.md overview

`AGENTS.md` is the 85-line canonical guidance for mission, product boundaries, Story Cluster evidence rules, planned technologies, design principles, engineering discipline, and relay requirements. Detailed material is linked instead of duplicated.

## CLAUDE.md compatibility approach

`CLAUDE.md` begins with `@AGENTS.md` and contains only the required Claude-specific import note. Local Claude preferences belong in the gitignored `CLAUDE.local.md`; `.claude/settings.local.json` is also ignored.

## Brand-package verification

The build and validation tools now resolve the five masters from `brand/source/locked-masters/`. The reference PNG exports and original validator are grouped under `brand/source/`. Brand validation passes all 11 groups, covering 19 SVGs, 31 PNGs, 75 manifest entries, transparency, geometry, minimum-size rendering, contrast, motion, and checksums.

## Validation commands

```sh
python brand/build_brand_package.py
python brand/validation/validate_cluster_mkt_brand_package.py
python scripts/validate_repository_foundation.py
git status --short
git diff --check
find . -maxdepth 4 -type f | sort
find . -maxdepth 4 -type d | sort
python scripts/build_repo_foundation_relay.py
```

## Validation results

- Brand package: **PASS, 11/11 groups**.
- Repository foundation: **PASS, 15/15 checks**.
- Locked masters: **PASS, 5/5 exact pre/post SHA-256 matches**.
- Documentation: all local Markdown links and documented Python command paths resolve.
- Hygiene: no dependencies, application scaffold, secrets, font binaries, caches, embedded SVG rasters, extracted relay trees, or active baked-checkerboard references.
- `git status --short` and `git diff --check` were executed but are unavailable as validation gates because the starting directory is not a Git worktree. Their exact output is retained in `validation/`.

Repository validator transcript:

```text
PASS: Required structure: 28 required files exist
PASS: Root hygiene: only intentional files and directories remain
PASS: Locked masters: one canonical copy each; all five SHA-256 hashes match
PASS: Cleanup: no caches, bytecode, .DS_Store, or bundled font binaries
PASS: Scaffolding boundary: no package manager or application manifests
PASS: Structural placeholders: README-only; no application code
PASS: Agent compatibility: CLAUDE.md imports canonical AGENTS.md exactly
PASS: Agent guidance: AGENTS.md is concise at 85 lines
PASS: Git hygiene: all required local-artifact patterns are ignored
PASS: Path references: all local Markdown links resolve
PASS: Path references: all documented Python command paths exist
PASS: SVG safety: no production SVG embeds raster data
PASS: Reference cleanup: no baked-checkerboard development files remain
PASS: Secret hygiene: no real .env file or key-like content detected
PASS: Relay hygiene: no extracted relay trees remain under relays/
SUMMARY: 15 passed, 0 failed
```

## What worked

The validated brand system remained reproducible after consolidation; the existing build completed, all brand validation remained green, the master hashes stayed identical, the new repository validator found no structural or reference problems, and the relay passed its own inventory and checksum audit.

## Remaining uncertainties

- There is no Git metadata at this path, so tracked/untracked classification, provenance by commit, branch state, and a native Git diff are unavailable.
- Brand-owner approvals previously identified for the outlined wordmark typeface, final editorial serif, lockup/social composition, edition palette, and jurisdiction-specific trademark usage remain outside this structural phase.

## Remaining blockers

No technical blocker prevents the next local scaffolding phase. A version-control decision is needed before anyone expects commits, branches, or Git-based change review.

## Items requiring user approval

- Decide whether the next phase should initialize Git here or work from a separately supplied version-controlled repository.
- Retain the prior brand package’s listed visual, typography, and trademark approvals as product-owner review items.

## Recommended next phase

Review this relay, choose the version-control starting point, then scaffold the React/Vite/TypeScript web application and Cloudflare Worker boundaries in a separate task. Keep Supabase and other external services configuration-only until explicitly authorized, and use the product, architecture, ADR, and agent guidance now present.

## Reproduction commands

From the repository root:

```sh
python brand/build_brand_package.py
python brand/validation/validate_cluster_mkt_brand_package.py
python scripts/validate_repository_foundation.py
python scripts/build_brand_relay.py
python scripts/build_repo_foundation_relay.py
```

## SHA-256 hashes

Locked source masters:

- `cluster-mkt-mark-dimensional-light.svg` — `66496cfe8dc2d6abb51c5b5a58824ca751db2de0d9a65be621f083bc075b11a1`
- `cluster-mkt-mark-dimensional-dark.svg` — `b8c4d7a36ae24daf5bb6e785dc41d9e6c4b01649e5eb5c55959763b5faa3405b`
- `cluster-mkt-mark-flat.svg` — `2dfae7aaf3524a80fe86a56f2fb3a1fa01b866c55abf11e3faf86aa6ef8ca992`
- `cluster-mkt-mark-monochrome-black.svg` — `037232276468c91ce7bb70daac33bc615f83ee3942855d4bd7b337e074fe5850`
- `cluster-mkt-mark-monochrome-white.svg` — `b676c0856aaa5b0c2bca0a687df8519b5c2c069044fa2e40ce0605c44b703542`

Previous brand relay: `57bc31489360c7ee38dd4b8a9b3f39807787c5aff692514545d16dad46232757`. Every relay member is inventoried in `manifest.json`; its self-entry documents the canonicalized self-checksum convention. Relay content short hash: `bcfaccd8`.

## Suggested Codex profile for the next phase

Heavy — GPT-5.6 Sol High.

## PLAIN-ENGLISH TRANSLATION

The loose logo sources and exports are now stored with the rest of the brand system instead of cluttering the project root. Disposable Mac metadata and the two old checkerboard-reference images are gone. The historical brand handoff is in `relays/`, and build/validation tools are in sensible permanent locations.

The new folders describe where the future website, worker, shared logic, UI, configuration, collection pipeline, tests, and scripts will live, but they contain no fake or premature application code. Codex and Claude Code now read the same short rulebook: `AGENTS.md` is authoritative, and `CLAUDE.md` imports it.

The only structural uncertainty is that this directory arrived without Git history, so there was no tracked-file state or diff to preserve. Nothing else was ambiguous enough to retain or discard. Next, after choosing how Git should be established, build the application skeleton as a separate phase while treating the validated brand package as locked.

Exact relay: `cluster-mkt-repo-foundation-relay-2026-07-28-bcfaccd8.zip`.
