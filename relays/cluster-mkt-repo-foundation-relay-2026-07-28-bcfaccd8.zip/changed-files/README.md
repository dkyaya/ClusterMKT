# Cluster MKT™

**All your sources, in one Cluster™**

Cluster MKT™ does not tell investors what to buy. It provides a clearer, faster way to understand the information that may influence their investment decisions.

Cluster MKT is planned as a market-information hub for retail investors. Its core unit is the Story Cluster: a provenance-aware organization of relevant primary and secondary sources, competing interpretations, uncertainty, related reading, and permitted listening material.

## Current status

Repository foundation and the validated brand system are complete. Application scaffolding has not begun. No frontend, backend, authentication, database, collection workflow, external API connection, or deployment infrastructure is implemented or connected.

This directory is currently local-only and is not a Git repository. No deployment or remote integration is implied.

## Repository layout

- `apps/` — planned web and worker applications.
- `packages/` — planned shared domain, UI, and configuration packages.
- `pipelines/` — planned collection and Story Cluster processing workflows.
- `brand/` — authoritative locked masters, production assets, tokens, tooling, and validation.
- `docs/` — product foundation, planned architecture, and decisions.
- `scripts/` — durable repository and brand support scripts.
- `tests/` — planned cross-package regression and integration tests.
- `relays/` — auditable phase handoffs.

Each unimplemented area contains a README describing its intended boundary. No placeholder application code or package-manager workspace has been created.

## Brand validation

Run from this directory:

```sh
python brand/build_brand_package.py
python brand/validation/validate_cluster_mkt_brand_package.py
```

The build verifies locked SVG hashes before and after generation. The validator must report `PASS` before brand assets are distributed.

## Documentation

- [Product foundation](docs/product/PRODUCT_FOUNDATION.md)
- [Planned architecture](docs/architecture/PLANNED_ARCHITECTURE.md)
- [Architecture decisions](docs/decisions/README.md)
- [Brand package](brand/README.md)
- [Brand guidelines](brand/BRAND_GUIDELINES.md)
- [Shared agent guidance](AGENTS.md)
- [Claude Code compatibility](CLAUDE.md)
