# Web application

## Responsibility

Planned React, Vite, and TypeScript browser experience for Story Clusters, personalization, and accessible brand presentation.

## Belongs here

Routes, screens, client state, browser integration, and composition of shared domain contracts and UI components.

## Does not belong here

Collection pipelines, clustering logic, secrets, publisher credentials, database administration, or reusable domain/UI code owned by packages.

## Status and dependencies

Not scaffolded. Future work depends on approved workspace tooling, `packages/core`, `packages/ui`, `packages/config`, and the validated `brand/` system.
