# Worker application

## Responsibility

Planned Cloudflare Worker boundary for server-side requests, approved integrations, and scheduled orchestration.

## Belongs here

Validated server handlers, secret-safe orchestration, and adapters to approved persistence or pipeline modules.

## Does not belong here

Browser presentation, publisher-account credentials, undocumented endpoints, or domain rules that belong in `packages/core`.

## Status and dependencies

Not scaffolded. Cloudflare and Supabase are planned only; no service is configured. Future work depends on approved manifests, domain contracts, and pipeline boundaries.
