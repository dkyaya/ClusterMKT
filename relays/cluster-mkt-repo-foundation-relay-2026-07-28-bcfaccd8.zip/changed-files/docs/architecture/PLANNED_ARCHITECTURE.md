# Planned architecture

## Status

This document describes intended boundaries. No application, service, database, workflow, endpoint, schema, integration, or deployment described here is implemented yet.

## Planned information flow

```text
Publisher feeds, APIs, filings, investor-relations sources, and podcast metadata
↓
Collection and normalization
↓
Entity resolution and relevance scoring
↓
Duplicate detection and Story Clustering
↓
Claim-level provenance and cluster summaries
↓
Reusable written and audio modules
↓
Personalized web experience
```

The planned platform choices are React, Vite, and TypeScript for the web experience; Cloudflare Pages and Workers for hosting and edge execution; Supabase authentication and PostgreSQL for identity and durable data; scheduled collection workflows; and Kokoro for initial TTS experimentation. These are planned choices, not installed dependencies or connected services.

## Component boundaries

### `apps/web`

Planned browser application for Story Cluster discovery, Overview/Read/Listen tabs, customization, account-facing experiences, and accessible light/dark/edition presentation. It consumes shared domain contracts and UI components; it does not own collection or clustering logic.

### `apps/worker`

Planned server-side and scheduled execution boundary for validated requests, orchestration, and approved integrations. It must protect secrets and keep publisher credentials out of scope.

### `packages/core`

Planned framework-independent domain types, stable identifiers, provenance structures, validation rules, relevance logic, and Story Cluster contracts.

### `packages/ui`

Planned reusable interface components and accessibility behavior aligned with the locked brand system. Domain decision logic does not belong here.

### `packages/config`

Planned shared TypeScript, build, lint, and test configuration once the actual toolchain is approved. It must not contain secrets or environment-specific credentials.

### `pipelines`

Planned collection, normalization, entity resolution, duplicate detection, relevance scoring, clustering, claim-provenance, summary-module, and audio-module workflows. Each transformation must preserve source metadata and explicit failure states.

### `brand`

Authoritative locked mark sources, production exports, tokens, documentation, build tooling, and validation. Visual changes require explicit approval and full revalidation.

### `tests`

Planned cross-component regression, provenance, relevance, clustering, accessibility, and integration tests. Failed relevance and clustering edge cases should become permanent fixtures where practical.

### `scripts`

Durable local automation for validation, maintenance, reproducible generation, and relay creation. One-off scratch work does not belong here.

### `relays`

Auditable phase handoffs containing changed files, validation evidence, decisions, uncertainties, reproduction commands, and checksums. Previous relay ZIPs must not be nested in new relays.

## Cross-cutting constraints

All external data must be validated. Provenance survives every transformation. Secrets never reach the client. Deterministic processing is preferred before model inference. Model output requires a fallback or explicit failure state, and model confidence is never evidence.
