# Core package

## Responsibility

Planned framework-independent domain contracts and deterministic Story Cluster logic.

## Belongs here

Stable identifiers, validated types, provenance, claim structures, relevance and clustering contracts, and reusable business rules.

## Does not belong here

React components, browser APIs, deployment adapters, secrets, or vendor-specific persistence code.

## Status and dependencies

Not implemented. It should become the lowest-level application package and remain independently testable.
