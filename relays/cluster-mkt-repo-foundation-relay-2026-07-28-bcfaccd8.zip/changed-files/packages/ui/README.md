# UI package

## Responsibility

Planned reusable, accessible interface components aligned with the Cluster MKT brand system.

## Belongs here

Presentational primitives, Story Cluster UI components, theme and edition bindings, accessibility behavior, and reduced-motion support.

## Does not belong here

Collection, source adjudication, clustering decisions, secrets, or app-specific routing.

## Status and dependencies

Not implemented. Future work depends on approved web tooling, `packages/core` contracts, and `brand/` tokens and assets.
