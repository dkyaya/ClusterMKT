# Scripts

## Responsibility

Durable local automation for repository maintenance, validation, reproducible generation, and relay creation.

## Belongs here

Documented scripts with stable inputs, explicit outputs, safe failure behavior, and reproduction commands.

## Does not belong here

Application runtime code, one-off scratch files, caches, embedded secrets, dependencies, or obsolete duplicate tooling.

## Status and dependencies

Contains the retained brand-relay builder and the repository-foundation validator. Repository-foundation relay tooling supports this phase’s reproducible handoff. Scripts depend on existing local Python libraries; no dependency was installed.

Run repository checks from the root with `python scripts/validate_repository_foundation.py`. Rebuild a brand-only handoff with `python scripts/build_brand_relay.py` after the brand validator passes.
