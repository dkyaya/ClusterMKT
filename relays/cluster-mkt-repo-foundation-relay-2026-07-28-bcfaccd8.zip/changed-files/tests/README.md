# Tests

## Responsibility

Planned cross-package regression, integration, provenance, relevance, clustering, accessibility, and contract tests.

## Belongs here

Stable fixtures, adversarial relevance cases, failed clustering edge cases, accessibility checks, and integration tests that span package boundaries.

## Does not belong here

Production assets, temporary browser output, secrets, or tests owned entirely by a future package’s local test directory.

## Status and dependencies

No application tests exist because application scaffolding has not begun. The existing brand validator remains under `brand/validation/`.
