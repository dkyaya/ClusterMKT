# Cleanup log

All deletions were adjudicated before removal. None was tracked because the starting directory had no Git metadata. Byte hashes were captured before deletion.

| Removed path | Pre-cleanup SHA-256 | Reason and authoritative replacement |
| --- | --- | --- |
| `.DS_Store` | `e9a604a733f6221f97a9eb5962e76761bc56195bff468fd4e02c506c7a098637` | macOS metadata; replaced by .gitignore coverage |
| `cluster-mkt-dimensional-reference-light-2048.png` | `37fb050a4bd3b2cf741fef944729091c355b68a5d1d788c8fb9763a5af5b326d` | baked-checkerboard development reference; validated production masters and previews remain |
| `cluster-mkt-vector-deliverables-reference-sheet-2048.png` | `a715e08df340286efc91ea796301ef96f0dc16e512d69849920cfad3d5e79f29` | superseded baked-checkerboard reference sheet; canonical brand previews remain |

Four `__pycache__` directories created only by local verification were also removed before final validation. They are not counted as starting-repository deletions because they did not exist during the initial inventory.

No ambiguous unique file was deleted. No font, dependency, application code, or secret was introduced.
